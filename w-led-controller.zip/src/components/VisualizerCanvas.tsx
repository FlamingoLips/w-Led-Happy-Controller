"use client";

import React, { useEffect, useRef, useState } from "react";
import { WledDeviceState } from "@/lib/wled-constants";
import { sampleEffectColor, rgbToHex } from "@/lib/wled-helpers";
import { Eye, Sparkles, Grid, CircleDot, Activity } from "lucide-react";

interface VisualizerCanvasProps {
  state: WledDeviceState;
  ledCount: number;
  matrixWidth?: number;
  matrixHeight?: number;
}

export function VisualizerCanvas({
  state,
  ledCount,
  matrixWidth = 0,
  matrixHeight = 0,
}: VisualizerCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [viewMode, setViewMode] = useState<"strip" | "matrix" | "ring">(() =>
    matrixWidth > 0 && matrixHeight > 0 ? "matrix" : "strip"
  );
  const [hoveredLed, setHoveredLed] = useState<{
    index: number;
    rgb: [number, number, number];
    hex: string;
    segName: string;
  } | null>(null);
  const [fps, setFps] = useState<number>(60);

  const stateRef = useRef(state);
  stateRef.current = state;
  const isMatrix = matrixWidth > 0 && matrixHeight > 0;

  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsUpdate = lastTime;

    const render = (time: number) => {
      frameCount++;
      if (time - lastFpsUpdate >= 1000) {
        setFps(Math.round((frameCount * 1000) / (time - lastFpsUpdate)));
        frameCount = 0;
        lastFpsUpdate = time;
      }

      const canvas = canvasRef.current;
      if (!canvas) {
        animId = requestAnimationFrame(render);
        return;
      }

      const ctx = canvas.getContext("2d");
      if (!ctx) {
        animId = requestAnimationFrame(render);
        return;
      }

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const currentState = stateRef.current;
      const isOn = currentState.on;
      const masterBri = currentState.bri;

      // Dark background
      ctx.fillStyle = "#0c1017";
      ctx.fillRect(0, 0, width, height);

      // Subtle grid backdrop
      ctx.strokeStyle = "rgba(255, 255, 255, 0.03)";
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Pre-calculate colors for each LED index
      const ledColors: [number, number, number][] = [];
      for (let i = 0; i < ledCount; i++) {
        // Find which segment owns this LED
        const seg = currentState.seg.find(
          (s) => i >= s.start && i < s.stop && s.on
        );

        if (!seg || !isOn) {
          ledColors.push([12, 16, 23]); // turned off LED dark tint
        } else {
          const col = sampleEffectColor(i, ledCount, seg, time, masterBri);
          ledColors.push(col);
        }
      }

      // Render based on view mode
      if (viewMode === "matrix" && isMatrix) {
        const cols = matrixWidth;
        const rows = matrixHeight;
        const pad = 3;
        const ledSize = Math.min((width - (cols + 1) * pad) / cols, (height - (rows + 1) * pad) / rows);
        const offsetX = (width - (cols * (ledSize + pad))) / 2;
        const offsetY = (height - (rows * (ledSize + pad))) / 2;

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const index = r * cols + c;
            if (index >= ledCount) continue;
            const [cr, cg, cb] = ledColors[index];
            const x = offsetX + c * (ledSize + pad);
            const y = offsetY + r * (ledSize + pad);

            // Glow for illuminated LEDs
            if (cr > 30 || cg > 30 || cb > 30) {
              ctx.shadowColor = `rgb(${cr},${cg},${cb})`;
              ctx.shadowBlur = Math.min(10, ledSize * 0.8);
            } else {
              ctx.shadowBlur = 0;
            }

            ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
            ctx.beginPath();
            ctx.arc(x + ledSize / 2, y + ledSize / 2, Math.max(2, ledSize / 2 - 1), 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          }
        }
      } else if (viewMode === "ring") {
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) * 0.38;
        const ledRadius = Math.max(3, Math.min(9, (2 * Math.PI * radius) / (ledCount * 2.2)));

        // Subtle guide ring
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
        ctx.lineWidth = 1;
        ctx.stroke();

        for (let i = 0; i < ledCount; i++) {
          const angle = (i / ledCount) * Math.PI * 2 - Math.PI / 2;
          const x = centerX + Math.cos(angle) * radius;
          const y = centerY + Math.sin(angle) * radius;
          const [cr, cg, cb] = ledColors[i];

          if (cr > 30 || cg > 30 || cb > 30) {
            ctx.shadowColor = `rgb(${cr},${cg},${cb})`;
            ctx.shadowBlur = 8;
          } else {
            ctx.shadowBlur = 0;
          }

          ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
          ctx.beginPath();
          ctx.arc(x, y, ledRadius, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      } else {
        // Linear 1D LED Strip view with smooth glow bar and individual nodes
        const padding = 28;
        const availableWidth = width - padding * 2;
        const ledSpacing = availableWidth / (ledCount - 1 || 1);
        const yCenter = height / 2;
        const nodeRadius = Math.max(2.5, Math.min(6, ledSpacing * 0.4));

        // Background PCB strip track
        ctx.fillStyle = "#161d27";
        ctx.fillRect(padding - 8, yCenter - 10, availableWidth + 16, 20);

        // Copper traces on strip
        ctx.strokeStyle = "#273549";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(padding - 6, yCenter - 5);
        ctx.lineTo(padding + availableWidth + 6, yCenter - 5);
        ctx.moveTo(padding - 6, yCenter + 5);
        ctx.lineTo(padding + availableWidth + 6, yCenter + 5);
        ctx.stroke();

        // Segments separator lines
        currentState.seg.forEach((seg) => {
          if (seg.start > 0 && seg.start < ledCount) {
            const segX = padding + seg.start * ledSpacing - ledSpacing / 2;
            ctx.strokeStyle = "rgba(0, 240, 255, 0.5)";
            ctx.setLineDash([2, 2]);
            ctx.beginPath();
            ctx.moveTo(segX, yCenter - 16);
            ctx.lineTo(segX, yCenter + 16);
            ctx.stroke();
            ctx.setLineDash([]);
          }
        });

        // Ambient diffuse light glow beneath strip
        const glowCanvas = document.createElement("canvas");
        glowCanvas.width = width;
        glowCanvas.height = 30;
        const glowCtx = glowCanvas.getContext("2d");
        if (glowCtx) {
          for (let i = 0; i < ledCount; i += 2) {
            const [cr, cg, cb] = ledColors[i];
            if (cr + cg + cb > 30) {
              const gx = padding + i * ledSpacing;
              const grad = glowCtx.createRadialGradient(gx, 15, 0, gx, 15, 35);
              grad.addColorStop(0, `rgba(${cr},${cg},${cb}, 0.35)`);
              grad.addColorStop(1, "rgba(0,0,0,0)");
              glowCtx.fillStyle = grad;
              glowCtx.fillRect(gx - 35, 0, 70, 30);
            }
          }
          ctx.drawImage(glowCanvas, 0, yCenter - 15);
        }

        // Draw physical LED SMD packages & emitters
        for (let i = 0; i < ledCount; i++) {
          const x = padding + i * ledSpacing;
          const [cr, cg, cb] = ledColors[i];

          // SMD package white/black border
          ctx.fillStyle = "#222d3d";
          ctx.fillRect(x - nodeRadius - 1.5, yCenter - nodeRadius - 1.5, (nodeRadius + 1.5) * 2, (nodeRadius + 1.5) * 2);

          // Emitter dot
          if (cr > 30 || cg > 30 || cb > 30) {
            ctx.shadowColor = `rgb(${cr},${cg},${cb})`;
            ctx.shadowBlur = 10;
          } else {
            ctx.shadowBlur = 0;
          }

          ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
          ctx.beginPath();
          ctx.arc(x, yCenter, nodeRadius, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // LED index markers every 10 LEDs
          if (i % 10 === 0 || i === ledCount - 1) {
            ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
            ctx.font = "9px monospace";
            ctx.textAlign = "center";
            ctx.fillText(i.toString(), x, yCenter + 26);
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [ledCount, isMatrix, matrixWidth, matrixHeight, viewMode]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * canvas.width;

    if (viewMode === "strip") {
      const padding = 28;
      const availableWidth = canvas.width - padding * 2;
      const ledSpacing = availableWidth / (ledCount - 1 || 1);
      const index = Math.round((mouseX - padding) / ledSpacing);

      if (index >= 0 && index < ledCount) {
        const seg = state.seg.find((s) => index >= s.start && index < s.stop);
        const col = sampleEffectColor(index, ledCount, seg || state.seg[0], performance.now(), state.bri);
        setHoveredLed({
          index,
          rgb: col,
          hex: rgbToHex(col[0], col[1], col[2]),
          segName: seg?.name || "Unassigned",
        });
        return;
      }
    }
    setHoveredLed(null);
  };

  return (
    <div className="relative rounded-2xl border border-slate-800 bg-slate-900/90 shadow-2xl backdrop-blur-md overflow-hidden">
      {/* Top visualizer status bar */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800/80 bg-slate-950/60">
        <div className="flex items-center space-x-2">
          <span className="relative flex h-2.5 w-2.5">
            {state.on && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            )}
            <span
              className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                state.on ? "bg-emerald-500 shadow-[0_0_8px_#10B981]" : "bg-slate-600"
              }`}
            />
          </span>
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            Live Strip View ({ledCount} LEDs)
          </span>
          <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
            • {state.seg.length} {state.seg.length === 1 ? "Segment" : "Segments"}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* View mode toggle */}
          <div className="flex bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/50">
            <button
              onClick={() => setViewMode("strip")}
              className={`px-2 py-0.5 text-xs font-medium rounded-md transition-all flex items-center gap-1 ${
                viewMode === "strip"
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="w-3 h-3" />
              1D Strip
            </button>
            <button
              onClick={() => setViewMode("ring")}
              className={`px-2 py-0.5 text-xs font-medium rounded-md transition-all flex items-center gap-1 ${
                viewMode === "ring"
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <CircleDot className="w-3 h-3" />
              Ring
            </button>
            {isMatrix && (
              <button
                onClick={() => setViewMode("matrix")}
                className={`px-2 py-0.5 text-xs font-medium rounded-md transition-all flex items-center gap-1 ${
                  viewMode === "matrix"
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Grid className="w-3 h-3" />
                2D Grid
              </button>
            )}
          </div>

          <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded border border-slate-700/40">
            <Activity className="w-3 h-3 text-emerald-400" />
            <span>{fps} FPS</span>
          </div>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="p-3 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative">
        <canvas
          ref={canvasRef}
          width={880}
          height={viewMode === "matrix" ? 320 : viewMode === "ring" ? 220 : 120}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoveredLed(null)}
          className="w-full h-auto rounded-xl border border-slate-800/60 bg-slate-950 shadow-inner cursor-crosshair block"
        />

        {/* Hover Inspector Tooltip */}
        {hoveredLed && (
          <div className="absolute top-5 right-5 pointer-events-none flex items-center space-x-2 bg-slate-900/95 border border-cyan-500/40 px-3 py-1.5 rounded-lg shadow-xl text-xs backdrop-blur-md animate-fade-in">
            <div
              className="w-3.5 h-3.5 rounded-full border border-white/20 shadow"
              style={{ backgroundColor: hoveredLed.hex }}
            />
            <span className="font-mono text-cyan-300 font-bold">LED #{hoveredLed.index}</span>
            <span className="font-mono text-slate-300">{hoveredLed.hex}</span>
            <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
              {hoveredLed.segName}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
