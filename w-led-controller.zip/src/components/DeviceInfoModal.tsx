"use client";

import React from "react";
import { Device } from "@/db/schema";
import { WledDeviceState } from "@/lib/wled-constants";
import { estimatePowerConsumption } from "@/lib/wled-helpers";
import {
  X,
  Cpu,
  Wifi,
  HardDrive,
  Zap,
  Clock,
  Activity,
  Layers,
  Server,
  ShieldCheck,
} from "lucide-react";

interface DeviceInfoModalProps {
  device: Device;
  state: WledDeviceState;
  onClose: () => void;
}

export function DeviceInfoModal({ device, state, onClose }: DeviceInfoModalProps) {
  const powerStats = estimatePowerConsumption(
    state,
    device.ledCount,
    device.voltage,
    device.maxCurrentMa
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center space-x-2">
            <Server className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                {device.name} — System Diagnostics
              </h3>
              <p className="text-[11px] font-mono text-slate-400">
                WLED 0.14.4 &bull; {device.isVirtual ? "Virtual Emulated Node" : "Physical ESP Device"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Status highlight */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
              </span>
              <div>
                <div className="text-xs font-bold text-slate-200">
                  Controller Online & Active
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  IP: {device.ipAddress} &bull; Port: 80 / 21324
                </div>
              </div>
            </div>
            <div className="text-right font-mono text-xs text-emerald-400 font-bold">
              60 FPS Target
            </div>
          </div>

          {/* Specs Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* ESP Architecture */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  Microcontroller
                </span>
              </div>
              <div className="font-bold text-slate-200">ESP32-D0WDQ6 Rev 1</div>
              <div className="text-[10px] text-slate-500 font-mono">
                Dual Core @ 240MHz &bull; 4MB Flash
              </div>
            </div>

            {/* Memory / Heap */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <HardDrive className="w-4 h-4 text-purple-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  Free Heap
                </span>
              </div>
              <div className="font-bold text-slate-200">184,320 Bytes</div>
              <div className="text-[10px] text-slate-500 font-mono">
                57.6% Free &bull; LittleFS OK
              </div>
            </div>

            {/* Wi-Fi RSSI */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Wifi className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  Wi-Fi Signal
                </span>
              </div>
              <div className="font-bold text-slate-200">-52 dBm (Excellent)</div>
              <div className="text-[10px] text-slate-500 font-mono">
                SSID: Home_IoT_2.4G &bull; Ch 6
              </div>
            </div>

            {/* Uptime */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Clock className="w-4 h-4 text-amber-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  System Uptime
                </span>
              </div>
              <div className="font-bold text-slate-200">14d 6h 32m</div>
              <div className="text-[10px] text-slate-500 font-mono">
                Zero watchdog resets
              </div>
            </div>

            {/* LED Strip configuration */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  LED Geometry
                </span>
              </div>
              <div className="font-bold text-slate-200">{device.ledCount} Pixels</div>
              <div className="text-[10px] text-slate-500 font-mono">
                {device.matrixWidth && device.matrixHeight
                  ? `Matrix: ${device.matrixWidth}x${device.matrixHeight} (2D)`
                  : "Linear Strip (1D) WS2812B/SK6812"}
              </div>
            </div>

            {/* Power Limiter */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Zap className="w-4 h-4 text-rose-400" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">
                  Power Limit
                </span>
              </div>
              <div className="font-bold text-slate-200">
                {powerStats.currentMa} / {device.maxCurrentMa} mA
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                {powerStats.watts}W @ {device.voltage}V &bull; ABL Active
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-300 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              WLED ABL (Automatic Brightness Limiter) is safeguarding your power supply from brownouts and over-current conditions.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
}
