"use client";

import React, { useState, useEffect } from "react";
import { WledDeviceState } from "@/lib/wled-constants";
import {
  Moon,
  Radio,
  Terminal,
  Copy,
  Check,
  Send,
  Clock,
  Sparkles,
} from "lucide-react";

interface AutomationTabProps {
  state: WledDeviceState;
  onUpdateState: (patch: Partial<WledDeviceState>) => void;
}

export function AutomationTab({ state, onUpdateState }: AutomationTabProps) {
  const [nightlightDuration, setNightlightDuration] = useState(
    state.nl?.dur ?? 15
  );
  const [targetBri, setTargetBri] = useState(state.nl?.tbri ?? 0);
  const [nlActive, setNlActive] = useState(state.nl?.on ?? false);
  const [remainingSec, setRemainingSec] = useState(nightlightDuration * 60);

  // Raw JSON console state
  const [jsonInput, setJsonInput] = useState(JSON.stringify(state, null, 2));
  const [jsonStatus, setJsonStatus] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setJsonInput(JSON.stringify(state, null, 2));
  }, [state]);

  // Nightlight countdown effect
  useEffect(() => {
    if (!nlActive) return;
    const interval = setInterval(() => {
      setRemainingSec((prev) => {
        if (prev <= 1) {
          setNlActive(false);
          onUpdateState({
            on: targetBri > 0,
            bri: targetBri,
            nl: { ...state.nl, on: false, rem: 0 },
          });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [nlActive, targetBri, state.nl, onUpdateState]);

  const toggleNightlight = () => {
    const nextState = !nlActive;
    setNlActive(nextState);
    if (nextState) {
      setRemainingSec(nightlightDuration * 60);
    }
    onUpdateState({
      nl: {
        ...state.nl,
        on: nextState,
        dur: nightlightDuration,
        tbri: targetBri,
      },
    });
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(state, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendCustomJson = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      onUpdateState(parsed);
      setJsonStatus("Successfully sent WLED payload!");
      setTimeout(() => setJsonStatus(null), 3000);
    } catch {
      setJsonStatus("Error: Invalid JSON format");
      setTimeout(() => setJsonStatus(null), 3000);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Nightlight Countdown Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
            <Moon className="w-4 h-4 text-purple-400" />
            <span>WLED Nightlight Timer</span>
          </div>

          <button
            onClick={toggleNightlight}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md ${
              nlActive
                ? "bg-purple-500 text-slate-950 shadow-purple-500/20"
                : "bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700"
            }`}
          >
            {nlActive ? "NIGHTLIGHT ACTIVE" : "ENABLE NIGHTLIGHT"}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <label className="text-xs text-slate-400 font-medium block">
              Duration (Minutes)
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="number"
                min="1"
                max="120"
                value={nightlightDuration}
                disabled={nlActive}
                onChange={(e) => setNightlightDuration(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none"
              />
              <span className="text-xs text-slate-400">mins</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <label className="text-xs text-slate-400 font-medium block">
              Target Brightness ({targetBri === 0 ? "Off" : `${targetBri}/255`})
            </label>
            <input
              type="range"
              min="0"
              max="100"
              value={targetBri}
              disabled={nlActive}
              onChange={(e) => setTargetBri(Number(e.target.value))}
              className="w-full h-2 rounded-lg bg-slate-900 accent-purple-400"
            />
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-center text-center">
            <div className="text-[10px] text-slate-500 font-mono uppercase">
              Time Remaining
            </div>
            <div className="text-2xl font-mono font-bold text-purple-300">
              {nlActive ? formatTime(remainingSec) : "Idle"}
            </div>
          </div>
        </div>
      </div>

      {/* UDP Sync Network Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span>WLED UDP Sync (Multi-controller Link)</span>
          </div>
          <span className="text-xs text-slate-500 font-mono">Port 21324</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() =>
              onUpdateState({
                udpn: { ...state.udpn, send: !state.udpn?.send },
              })
            }
            className={`p-4 rounded-xl border text-left transition-all ${
              state.udpn?.send
                ? "bg-emerald-950/40 border-emerald-500/60 text-emerald-300 shadow-md"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold">Broadcast Notifications (Send)</span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                  state.udpn?.send ? "bg-emerald-500 text-slate-950 font-bold" : "bg-slate-800 text-slate-400"
                }`}
              >
                {state.udpn?.send ? "ENABLED" : "OFF"}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Broadcasts color and effect changes to other WLED strips on the network.
            </p>
          </button>

          <button
            onClick={() =>
              onUpdateState({
                udpn: { ...state.udpn, recv: !state.udpn?.recv },
              })
            }
            className={`p-4 rounded-xl border text-left transition-all ${
              state.udpn?.recv
                ? "bg-cyan-950/40 border-cyan-500/60 text-cyan-300 shadow-md"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold">Receive Synchronizations (Recv)</span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                  state.udpn?.recv ? "bg-cyan-500 text-slate-950 font-bold" : "bg-slate-800 text-slate-400"
                }`}
              >
                {state.udpn?.recv ? "ENABLED" : "OFF"}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Listens and reacts to incoming packets from a master WLED controller.
            </p>
          </button>
        </div>
      </div>

      {/* Raw JSON Console */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>WLED JSON API Terminal (/json/state)</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyJson}
              className="px-2.5 py-1 text-xs rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy State"}</span>
            </button>
            <button
              onClick={handleSendCustomJson}
              className="px-3 py-1 text-xs font-bold rounded-lg bg-cyan-500 text-slate-950 hover:bg-cyan-400 flex items-center gap-1 shadow-md shadow-cyan-500/20"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Payload</span>
            </button>
          </div>
        </div>

        {jsonStatus && (
          <div
            className={`text-xs px-3 py-1.5 rounded-lg border ${
              jsonStatus.startsWith("Error")
                ? "bg-rose-950/40 border-rose-500/40 text-rose-300"
                : "bg-emerald-950/40 border-emerald-500/40 text-emerald-300"
            }`}
          >
            {jsonStatus}
          </div>
        )}

        <textarea
          rows={9}
          value={jsonInput}
          onChange={(e) => setJsonInput(e.target.value)}
          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
        />
        <div className="text-[11px] text-slate-500 font-mono">
          Tip: You can edit or paste raw WLED JSON payload and hit Send Payload to execute live.
        </div>
      </div>
    </div>
  );
}
