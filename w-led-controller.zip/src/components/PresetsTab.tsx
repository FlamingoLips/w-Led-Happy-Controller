"use client";

import React, { useState, useEffect, useRef } from "react";
import { WledDeviceState } from "@/lib/wled-constants";
import { rgbToHex } from "@/lib/wled-helpers";
import {
  Bookmark,
  Play,
  Pause,
  Plus,
  Trash2,
  Clock,
  Sparkles,
  Shuffle,
  SkipForward,
} from "lucide-react";

export interface PresetItem {
  id: number;
  name: string;
  quickLoadKey: number | null;
  stateData: string;
  createdAt?: string;
}

interface PresetsTabProps {
  deviceId: number;
  state: WledDeviceState;
  presetsList: PresetItem[];
  onLoadPreset: (presetState: WledDeviceState) => void;
  onRefreshPresets: () => void;
}

export function PresetsTab({
  deviceId,
  state,
  presetsList,
  onLoadPreset,
  onRefreshPresets,
}: PresetsTabProps) {
  const [newPresetName, setNewPresetName] = useState("");
  const [newQuickKey, setNewQuickKey] = useState<number | "">("");
  const [isSaving, setIsSaving] = useState(false);

  // Playlist State
  const [isPlayingPlaylist, setIsPlayingPlaylist] = useState(false);
  const [playlistIndex, setPlaylistIndex] = useState(0);
  const [playlistDurationSec, setPlaylistDurationSec] = useState(8);
  const [timeRemainingSec, setTimeRemainingSec] = useState(8);

  const playlistTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleSavePreset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPresetName.trim()) return;
    setIsSaving(true);

    try {
      const res = await fetch("/api/presets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId,
          name: newPresetName.trim(),
          quickLoadKey: newQuickKey ? Number(newQuickKey) : null,
          stateData: state,
        }),
      });

      if (res.ok) {
        setNewPresetName("");
        setNewQuickKey("");
        onRefreshPresets();
      }
    } catch (err) {
      console.error("Failed to save preset:", err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeletePreset = async (id: number) => {
    try {
      const res = await fetch(`/api/presets/${id}`, { method: "DELETE" });
      if (res.ok) {
        onRefreshPresets();
      }
    } catch (err) {
      console.error("Failed to delete preset:", err);
    }
  };

  const applyPreset = (preset: PresetItem) => {
    try {
      const parsed: WledDeviceState = JSON.parse(preset.stateData);
      onLoadPreset(parsed);
    } catch (err) {
      console.error("Failed to parse preset state:", err);
    }
  };

  // Automated Playlist Runner Effect
  useEffect(() => {
    if (!isPlayingPlaylist || presetsList.length === 0) {
      if (playlistTimerRef.current) clearInterval(playlistTimerRef.current);
      return;
    }

    // Apply the initial preset immediately
    applyPreset(presetsList[playlistIndex % presetsList.length]);
    setTimeRemainingSec(playlistDurationSec);

    const interval = setInterval(() => {
      setTimeRemainingSec((prev) => {
        if (prev <= 1) {
          // Advance to next preset
          setPlaylistIndex((curr) => {
            const nextIdx = (curr + 1) % presetsList.length;
            applyPreset(presetsList[nextIdx]);
            return nextIdx;
          });
          return playlistDurationSec;
        }
        return prev - 1;
      });
    }, 1000);

    playlistTimerRef.current = interval;

    return () => {
      if (playlistTimerRef.current) clearInterval(playlistTimerRef.current);
    };
  }, [isPlayingPlaylist, playlistIndex, playlistDurationSec, presetsList.length]);

  return (
    <div className="space-y-6">
      {/* Playlist Runner Control Bar */}
      <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsPlayingPlaylist(!isPlayingPlaylist)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                isPlayingPlaylist
                  ? "bg-amber-500 text-slate-950 shadow-amber-500/20"
                  : "bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 shadow-cyan-500/20"
              }`}
            >
              {isPlayingPlaylist ? (
                <>
                  <Pause className="w-4 h-4 fill-current" />
                  <span>PAUSE PLAYLIST</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>RUN PRESET CYCLE</span>
                </>
              )}
            </button>

            {isPlayingPlaylist && (
              <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
                <span className="text-slate-400">Current:</span>
                <span className="text-cyan-400 font-bold truncate max-w-[140px]">
                  {presetsList[playlistIndex % presetsList.length]?.name}
                </span>
                <span className="text-slate-500 font-mono">
                  ({timeRemainingSec}s left)
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>Step:</span>
              <select
                value={playlistDurationSec}
                onChange={(e) => setPlaylistDurationSec(Number(e.target.value))}
                className="bg-slate-950 text-slate-200 border border-slate-800 rounded px-2 py-1 text-xs focus:outline-none"
              >
                <option value={4}>4 sec</option>
                <option value={8}>8 sec</option>
                <option value={15}>15 sec</option>
                <option value={30}>30 sec</option>
                <option value={60}>60 sec</option>
              </select>
            </div>

            {isPlayingPlaylist && (
              <button
                onClick={() => {
                  const nextIdx = (playlistIndex + 1) % presetsList.length;
                  setPlaylistIndex(nextIdx);
                  applyPreset(presetsList[nextIdx]);
                  setTimeRemainingSec(playlistDurationSec);
                }}
                className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white"
                title="Skip to next"
              >
                <SkipForward className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {isPlayingPlaylist && (
          <div className="mt-3 w-full bg-slate-950 h-1 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-cyan-400 transition-all duration-1000"
              style={{
                width: `${((playlistDurationSec - timeRemainingSec) / playlistDurationSec) * 100}%`,
              }}
            />
          </div>
        )}
      </div>

      {/* Save Current State Form */}
      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl backdrop-blur-md">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center space-x-2">
          <Bookmark className="w-4 h-4 text-cyan-400" />
          <span>Save Current Strip State as Preset</span>
        </div>

        <form onSubmit={handleSavePreset} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            placeholder="Preset Name (e.g. Cyberpunk Violet, Cozy Fireplace, Gaming)"
            value={newPresetName}
            onChange={(e) => setNewPresetName(e.target.value)}
            className="flex-1 px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            required
          />

          <input
            type="number"
            min="1"
            max="16"
            placeholder="Quick Key (1-16)"
            value={newQuickKey}
            onChange={(e) =>
              setNewQuickKey(e.target.value === "" ? "" : Number(e.target.value))
            }
            className="w-32 px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />

          <button
            type="submit"
            disabled={isSaving || !newPresetName.trim()}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Save Preset</span>
          </button>
        </form>
      </div>

      {/* Presets Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {presetsList.map((preset) => {
          let parsed: WledDeviceState | null = null;
          try {
            parsed = JSON.parse(preset.stateData);
          } catch {}

          const primaryCol = parsed?.seg?.[0]?.col?.[0] || [255, 255, 255];
          const secondaryCol = parsed?.seg?.[0]?.col?.[1] || [0, 0, 0];
          const hex1 = rgbToHex(primaryCol[0], primaryCol[1], primaryCol[2]);
          const hex2 = rgbToHex(secondaryCol[0], secondaryCol[1], secondaryCol[2]);

          return (
            <div
              key={preset.id}
              className="p-4 rounded-2xl border border-slate-800 bg-slate-900/80 hover:bg-slate-900 hover:border-slate-700 transition-all flex flex-col justify-between group shadow-lg"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center space-x-2">
                    {preset.quickLoadKey && (
                      <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono text-[10px] font-bold">
                        #{preset.quickLoadKey}
                      </span>
                    )}
                    <h4 className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                      {preset.name}
                    </h4>
                  </div>
                  <button
                    onClick={() => handleDeletePreset(preset.id)}
                    className="text-slate-600 hover:text-rose-400 transition-colors p-1"
                    title="Delete Preset"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Color swatches preview */}
                <div className="flex items-center space-x-2 my-2.5">
                  <div
                    className="w-5 h-5 rounded-md border border-white/20 shadow-sm"
                    style={{ backgroundColor: hex1 }}
                  />
                  <div
                    className="w-5 h-5 rounded-md border border-white/20 shadow-sm"
                    style={{ backgroundColor: hex2 }}
                  />
                  <div className="text-[10px] font-mono text-slate-400">
                    FX #{parsed?.seg?.[0]?.fx ?? 0} • Bri {parsed?.bri ?? 255}
                  </div>
                </div>
              </div>

              <button
                onClick={() => applyPreset(preset)}
                className="mt-3 w-full py-1.5 px-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 flex items-center justify-center gap-1.5 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Load Preset</span>
              </button>
            </div>
          );
        })}
      </div>

      {presetsList.length === 0 && (
        <div className="p-8 text-center rounded-2xl border border-slate-800 bg-slate-900/50 text-slate-400 text-sm">
          No presets saved yet. Save your favorite colors and animations above!
        </div>
      )}
    </div>
  );
}
