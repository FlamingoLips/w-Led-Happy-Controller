"use client";

import React, { useState, useMemo } from "react";
import { WledDeviceState, WLED_EFFECTS, WledEffect } from "@/lib/wled-constants";
import { Sparkles, Gauge, Flame, Search, Check, Zap } from "lucide-react";

interface EffectsTabProps {
  state: WledDeviceState;
  onUpdateState: (patch: Partial<WledDeviceState>) => void;
}

const CATEGORIES = [
  "All",
  "Classic",
  "Dynamic",
  "Nature & Fire",
  "Party & Rave",
  "Ambient",
  "Patterns",
] as const;

export function EffectsTab({ state, onUpdateState }: EffectsTabProps) {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const activeSegIdx =
    state.seg.findIndex((s) => s.sel) !== -1 ? state.seg.findIndex((s) => s.sel) : 0;
  const currentSeg = state.seg[activeSegIdx] || state.seg[0];

  const currentFx = currentSeg?.fx ?? 0;
  const currentSpeed = currentSeg?.sx ?? 128;
  const currentIntensity = currentSeg?.ix ?? 128;

  const filteredEffects = useMemo(() => {
    return WLED_EFFECTS.filter((fx) => {
      const matchCat =
        selectedCategory === "All" || fx.category === selectedCategory;
      const matchSearch =
        search.trim() === "" ||
        fx.name.toLowerCase().includes(search.toLowerCase()) ||
        fx.description.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, selectedCategory]);

  const setEffect = (fxId: number) => {
    const updatedSegs = [...state.seg];
    updatedSegs[activeSegIdx] = {
      ...currentSeg,
      fx: fxId,
    };
    onUpdateState({ seg: updatedSegs });
  };

  const setSpeed = (val: number) => {
    const updatedSegs = [...state.seg];
    updatedSegs[activeSegIdx] = {
      ...currentSeg,
      sx: val,
    };
    onUpdateState({ seg: updatedSegs });
  };

  const setIntensity = (val: number) => {
    const updatedSegs = [...state.seg];
    updatedSegs[activeSegIdx] = {
      ...currentSeg,
      ix: val,
    };
    onUpdateState({ seg: updatedSegs });
  };

  const getSpeedLabel = (val: number) => {
    if (val < 50) return "Crawl";
    if (val < 100) return "Slow";
    if (val < 160) return "Medium";
    if (val < 220) return "Fast";
    return "Turbo";
  };

  const getIntensityLabel = (val: number) => {
    if (val < 64) return "Subtle";
    if (val < 140) return "Balanced";
    if (val < 200) return "Intense";
    return "Maximum";
  };

  return (
    <div className="space-y-6">
      {/* Speed & Intensity Modulators Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
            <Gauge className="w-4 h-4 text-cyan-400" />
            <span>Effect Modulators (Active Segment: #{currentSeg.id})</span>
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Effect ID: <span className="text-cyan-400 font-bold">{currentFx}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Speed (sx) */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                SPEED (sx)
              </span>
              <div className="flex items-center space-x-2 font-mono">
                <span className="text-cyan-400 font-bold">{currentSpeed}</span>
                <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                  {getSpeedLabel(currentSpeed)}
                </span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="255"
              value={currentSpeed}
              onChange={(e) => setSpeed(parseInt(e.target.value, 10))}
              className="w-full h-2 rounded-lg appearance-none cursor-pointer bg-slate-900 accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0 (Frozen)</span>
              <span>128 (Normal)</span>
              <span>255 (Hyper)</span>
            </div>
          </div>

          {/* Intensity (ix) */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                INTENSITY (ix)
              </span>
              <div className="flex items-center space-x-2 font-mono">
                <span className="text-rose-400 font-bold">{currentIntensity}</span>
                <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                  {getIntensityLabel(currentIntensity)}
                </span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="255"
              value={currentIntensity}
              onChange={(e) => setIntensity(parseInt(e.target.value, 10))}
              className="w-full h-2 rounded-lg appearance-none cursor-pointer bg-slate-900 accent-rose-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0 (Muted)</span>
              <span>128 (Balanced)</span>
              <span>255 (High)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search 30+ WLED effects (e.g. Rainbow, Fire, Matrix, Aurora)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-900/90 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1.5 overflow-x-auto pb-1">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? "bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                    : "bg-slate-900/80 text-slate-400 border border-slate-800 hover:bg-slate-800 hover:text-slate-200"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Effects Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {filteredEffects.map((fx) => {
          const isActive = currentFx === fx.id;

          return (
            <button
              key={fx.id}
              onClick={() => setEffect(fx.id)}
              className={`relative flex flex-col justify-between p-3.5 rounded-xl border text-left transition-all group ${
                isActive
                  ? "bg-slate-800/95 border-cyan-400 shadow-lg shadow-cyan-950/60 ring-1 ring-cyan-400"
                  : "bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                    {fx.name}
                  </span>
                  {isActive && (
                    <span className="flex items-center text-[10px] text-cyan-400 font-bold">
                      <Check className="w-3.5 h-3.5 mr-0.5" />
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {fx.description}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span className="bg-slate-950 px-1.5 py-0.5 rounded text-slate-400 border border-slate-800">
                  {fx.category}
                </span>
                <span>FX #{fx.id}</span>
              </div>
            </button>
          );
        })}
      </div>

      {filteredEffects.length === 0 && (
        <div className="p-8 text-center rounded-2xl border border-slate-800 bg-slate-900/50 text-slate-400 text-sm">
          No effects found matching &quot;{search}&quot;.
        </div>
      )}
    </div>
  );
}
