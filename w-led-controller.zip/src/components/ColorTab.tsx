"use client";

import React, { useState } from "react";
import { WledDeviceState, QUICK_COLORS, WLED_PALETTES } from "@/lib/wled-constants";
import { rgbToHex, hexToRgb } from "@/lib/wled-helpers";
import { Palette, Check, Droplets } from "lucide-react";

interface ColorTabProps {
  state: WledDeviceState;
  onUpdateState: (patch: Partial<WledDeviceState>) => void;
}

export function ColorTab({ state, onUpdateState }: ColorTabProps) {
  // Active selected segment (defaults to mainseg or first selected)
  const activeSegIdx = state.seg.findIndex((s) => s.sel) !== -1
    ? state.seg.findIndex((s) => s.sel)
    : 0;

  const currentSeg = state.seg[activeSegIdx] || state.seg[0];
  const [activeSlot, setActiveSlot] = useState<0 | 1 | 2>(0);

  // Extract current slot color [R, G, B, W]
  const slotColor = currentSeg?.col?.[activeSlot] || [255, 0, 100, 0];
  const r = slotColor[0] ?? 255;
  const g = slotColor[1] ?? 0;
  const b = slotColor[2] ?? 0;
  const w = slotColor[3] ?? 0;
  const currentHex = rgbToHex(r, g, b);

  const updateColor = (newR: number, newG: number, newB: number, newW?: number) => {
    const nextCol = [...(currentSeg.col || [[255, 255, 255, 0], [0, 0, 0, 0], [0, 0, 0, 0]])];
    nextCol[activeSlot] = [
      Math.max(0, Math.min(255, newR)),
      Math.max(0, Math.min(255, newG)),
      Math.max(0, Math.min(255, newB)),
      newW !== undefined ? Math.max(0, Math.min(255, newW)) : w,
    ];

    const updatedSegs = [...state.seg];
    updatedSegs[activeSegIdx] = {
      ...currentSeg,
      col: nextCol,
    };

    onUpdateState({ seg: updatedSegs });
  };

  const setPalette = (palId: number) => {
    const updatedSegs = [...state.seg];
    updatedSegs[activeSegIdx] = {
      ...currentSeg,
      pal: palId,
    };
    onUpdateState({ seg: updatedSegs });
  };

  return (
    <div className="space-y-6">
      {/* Segment context indicator */}
      {state.seg.length > 1 && (
        <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
          <div className="text-slate-400">
            Applying color to segment:{" "}
            <span className="text-cyan-400 font-bold font-mono">
              #{currentSeg.id} {currentSeg.name ? `(${currentSeg.name})` : ""}
            </span>{" "}
            [LEDs {currentSeg.start}-{currentSeg.stop}]
          </div>
          <div className="text-slate-500 font-mono">
            {currentSeg.stop - currentSeg.start} LEDs
          </div>
        </div>
      )}

      {/* Primary / Secondary / Tertiary Color Slots */}
      <div className="grid grid-cols-3 gap-3">
        {(["Primary (Col 0)", "Secondary (Col 1)", "Tertiary (Col 2)"] as const).map(
          (label, idx) => {
            const col = currentSeg?.col?.[idx] || [0, 0, 0, 0];
            const hex = rgbToHex(col[0] || 0, col[1] || 0, col[2] || 0);
            const isSelected = activeSlot === idx;

            return (
              <button
                key={label}
                onClick={() => setActiveSlot(idx as 0 | 1 | 2)}
                className={`relative flex items-center space-x-3 p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? "bg-slate-800/90 border-cyan-400 shadow-md shadow-cyan-950/50 ring-1 ring-cyan-400/50"
                    : "bg-slate-900/60 border-slate-800 hover:bg-slate-800/40 text-slate-400"
                }`}
              >
                <div
                  className="w-10 h-10 rounded-lg shadow-inner border border-white/20 shrink-0"
                  style={{ backgroundColor: hex }}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide truncate">
                    {label}
                  </div>
                  <div className="text-xs font-mono font-bold text-slate-100 truncate">
                    {hex}
                  </div>
                </div>
                {isSelected && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
                )}
              </button>
            );
          }
        )}
      </div>

      {/* Main Color Picker Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Big Color Box and Hex Input */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="relative group">
              <div
                className="w-28 h-28 rounded-2xl shadow-2xl border-2 border-slate-700 transition-transform group-hover:scale-105"
                style={{ backgroundColor: currentHex }}
              />
              <input
                type="color"
                value={currentHex}
                onChange={(e) => {
                  const [newR, newG, newB] = hexToRgb(e.target.value);
                  updateColor(newR, newG, newB);
                }}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                title="Click to open system color wheel"
              />
            </div>

            <div className="w-full flex items-center justify-between bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-700">
              <span className="text-xs font-mono text-slate-400">HEX:</span>
              <input
                type="text"
                value={currentHex}
                onChange={(e) => {
                  if (e.target.value.startsWith("#") && e.target.value.length <= 7) {
                    const [newR, newG, newB] = hexToRgb(e.target.value);
                    updateColor(newR, newG, newB);
                  }
                }}
                className="w-20 bg-transparent text-right font-mono text-sm font-bold text-cyan-300 focus:outline-none"
              />
            </div>
            <span className="text-[10px] text-slate-500">Tap swatch for wheel</span>
          </div>

          {/* Precision RGB & W Sliders */}
          <div className="md:col-span-8 space-y-3.5">
            {/* Red */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-red-400 font-bold">R • RED</span>
                <span className="font-mono text-slate-300">{r}</span>
              </div>
              <input
                type="range"
                min="0"
                max="255"
                value={r}
                onChange={(e) => updateColor(parseInt(e.target.value, 10), g, b)}
                className="w-full h-2.5 rounded-lg appearance-none cursor-pointer bg-slate-950 border border-slate-800 accent-red-500"
                style={{
                  background: `linear-gradient(to right, #2a0808, #ef4444)`,
                }}
              />
            </div>

            {/* Green */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-emerald-400 font-bold">G • GREEN</span>
                <span className="font-mono text-slate-300">{g}</span>
              </div>
              <input
                type="range"
                min="0"
                max="255"
                value={g}
                onChange={(e) => updateColor(r, parseInt(e.target.value, 10), b)}
                className="w-full h-2.5 rounded-lg appearance-none cursor-pointer bg-slate-950 border border-slate-800 accent-emerald-500"
                style={{
                  background: `linear-gradient(to right, #052618, #10b981)`,
                }}
              />
            </div>

            {/* Blue */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-blue-400 font-bold">B • BLUE</span>
                <span className="font-mono text-slate-300">{b}</span>
              </div>
              <input
                type="range"
                min="0"
                max="255"
                value={b}
                onChange={(e) => updateColor(r, g, parseInt(e.target.value, 10))}
                className="w-full h-2.5 rounded-lg appearance-none cursor-pointer bg-slate-950 border border-slate-800 accent-blue-500"
                style={{
                  background: `linear-gradient(to right, #081a38, #3b82f6)`,
                }}
              />
            </div>

            {/* White channel for SK6812/RGBW strips */}
            <div className="space-y-1 pt-1 border-t border-slate-800/80">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-amber-200 font-bold flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5" />
                  W • WHITE CHANNEL (SK6812 / RGBW)
                </span>
                <span className="font-mono text-slate-300">{w}</span>
              </div>
              <input
                type="range"
                min="0"
                max="255"
                value={w}
                onChange={(e) => updateColor(r, g, b, parseInt(e.target.value, 10))}
                className="w-full h-2.5 rounded-lg appearance-none cursor-pointer bg-slate-950 border border-slate-800 accent-amber-300"
                style={{
                  background: `linear-gradient(to right, #1f1f1f, #fef3c7)`,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Color Swatches */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Quick Swatches & White Temperatures
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
          {QUICK_COLORS.map((qc) => {
            const isMatch =
              r === qc.rgb[0] && g === qc.rgb[1] && b === qc.rgb[2];

            return (
              <button
                key={qc.name}
                onClick={() => updateColor(qc.rgb[0], qc.rgb[1], qc.rgb[2])}
                className={`group flex items-center space-x-2.5 p-2 rounded-xl border text-left transition-all ${
                  isMatch
                    ? "bg-slate-800 border-cyan-400 ring-1 ring-cyan-400/50"
                    : "bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/60"
                }`}
              >
                <div
                  className="w-6 h-6 rounded-lg shadow shrink-0 border border-white/20 transition-transform group-hover:scale-110"
                  style={{ backgroundColor: qc.hex }}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-medium text-slate-300 truncate">
                    {qc.name}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500 truncate">
                    {qc.hex}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* WLED Built-in Palettes Library */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl backdrop-blur-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
            <Palette className="w-4 h-4 text-cyan-400" />
            <span>WLED Color Palettes (WLED 0.14+)</span>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {WLED_PALETTES.length} Curated Palettes
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {WLED_PALETTES.map((pal) => {
            const isActive = currentSeg.pal === pal.id;
            const gradientCss = `linear-gradient(to right, ${pal.colors.join(", ")})`;

            return (
              <button
                key={pal.id}
                onClick={() => setPalette(pal.id)}
                className={`relative p-3 rounded-xl border text-left transition-all ${
                  isActive
                    ? "bg-slate-800/90 border-cyan-400 shadow-md shadow-cyan-950/40 ring-1 ring-cyan-400/50"
                    : "bg-slate-950/50 border-slate-800/80 hover:bg-slate-800/50"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-200">
                    {pal.name}
                  </span>
                  {isActive && (
                    <span className="flex items-center text-[10px] text-cyan-400 font-bold">
                      <Check className="w-3 h-3 mr-0.5" />
                      Active
                    </span>
                  )}
                </div>

                {/* Gradient Strip */}
                <div
                  className="w-full h-4 rounded-md shadow-inner border border-white/10"
                  style={{ background: gradientCss }}
                />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
