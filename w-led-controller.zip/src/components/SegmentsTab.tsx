"use client";

import React from "react";
import { WledDeviceState, WledSegmentState } from "@/lib/wled-constants";
import {
  Layers,
  Plus,
  Trash2,
  SplitSquareVertical,
  RotateCcw,
  FlipHorizontal,
  Power,
  Sun,
  Check,
} from "lucide-react";

interface SegmentsTabProps {
  state: WledDeviceState;
  ledCount: number;
  onUpdateState: (patch: Partial<WledDeviceState>) => void;
}

export function SegmentsTab({
  state,
  ledCount,
  onUpdateState,
}: SegmentsTabProps) {
  const updateSegment = (segId: number, patch: Partial<WledSegmentState>) => {
    const updated = state.seg.map((s) => (s.id === segId ? { ...s, ...patch } : s));
    onUpdateState({ seg: updated });
  };

  const setSelectedSegment = (segId: number) => {
    const updated = state.seg.map((s) => ({
      ...s,
      sel: s.id === segId,
    }));
    onUpdateState({ seg: updated });
  };

  const addSegment = () => {
    // Find highest stop index or end of strip
    const lastSeg = state.seg[state.seg.length - 1];
    const newId = state.seg.reduce((max, s) => Math.max(max, s.id), -1) + 1;
    let start = 0;
    let stop = ledCount;

    if (lastSeg && lastSeg.stop < ledCount) {
      start = lastSeg.stop;
      stop = ledCount;
    } else if (state.seg.length > 0) {
      // Split the last segment in half
      const half = Math.floor((lastSeg.stop - lastSeg.start) / 2);
      if (half > 2) {
        lastSeg.stop = lastSeg.start + half;
        start = lastSeg.stop;
        stop = ledCount;
      }
    }

    const newSeg: WledSegmentState = {
      id: newId,
      start,
      stop,
      len: stop - start,
      grp: 1,
      spc: 0,
      of: 0,
      on: true,
      bri: 255,
      col: [
        [0, 240, 255, 0],
        [255, 0, 100, 0],
        [255, 255, 255, 0],
      ],
      fx: 6,
      sx: 128,
      ix: 128,
      pal: 0,
      sel: true,
      rev: false,
      mi: false,
      name: `Segment ${newId}`,
    };

    // Deselect other segments
    const updated = state.seg.map((s) => ({ ...s, sel: false })).concat(newSeg);
    onUpdateState({ seg: updated });
  };

  const removeSegment = (segId: number) => {
    if (state.seg.length <= 1) return;
    const remaining = state.seg.filter((s) => s.id !== segId);
    // If deleted segment was selected, select the first remaining
    if (!remaining.some((s) => s.sel) && remaining.length > 0) {
      remaining[0].sel = true;
    }
    onUpdateState({ seg: remaining });
  };

  const resetToOneSegment = () => {
    const defaultSeg: WledSegmentState = {
      id: 0,
      start: 0,
      stop: ledCount,
      len: ledCount,
      grp: 1,
      spc: 0,
      of: 0,
      on: true,
      bri: 255,
      col: state.seg[0]?.col || [[255, 0, 100, 0], [0, 240, 255, 0], [255, 255, 255, 0]],
      fx: state.seg[0]?.fx || 6,
      sx: state.seg[0]?.sx || 128,
      ix: state.seg[0]?.ix || 128,
      pal: state.seg[0]?.pal || 0,
      sel: true,
      rev: false,
      mi: false,
      name: "Main Unified Strip",
    };
    onUpdateState({ seg: [defaultSeg] });
  };

  const splitInTwo = () => {
    const half = Math.floor(ledCount / 2);
    const seg1: WledSegmentState = {
      ...state.seg[0],
      id: 0,
      start: 0,
      stop: half,
      len: half,
      sel: true,
      name: "Zone 1 (First Half)",
    };
    const seg2: WledSegmentState = {
      ...state.seg[0],
      id: 1,
      start: half,
      stop: ledCount,
      len: ledCount - half,
      sel: false,
      fx: 8, // Fire
      name: "Zone 2 (Second Half)",
    };
    onUpdateState({ seg: [seg1, seg2] });
  };

  const splitInThree = () => {
    const third = Math.floor(ledCount / 3);
    const seg1: WledSegmentState = {
      ...state.seg[0],
      id: 0,
      start: 0,
      stop: third,
      len: third,
      sel: true,
      name: "Zone 1 (Left)",
    };
    const seg2: WledSegmentState = {
      ...state.seg[0],
      id: 1,
      start: third,
      stop: third * 2,
      len: third,
      sel: false,
      fx: 13, // Aurora
      name: "Zone 2 (Center)",
    };
    const seg3: WledSegmentState = {
      ...state.seg[0],
      id: 2,
      start: third * 2,
      stop: ledCount,
      len: ledCount - third * 2,
      sel: false,
      fx: 14, // Matrix
      name: "Zone 3 (Right)",
    };
    onUpdateState({ seg: [seg1, seg2, seg3] });
  };

  return (
    <div className="space-y-6">
      {/* Segment Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl backdrop-blur-md">
        <div className="flex items-center space-x-2">
          <Layers className="w-5 h-5 text-cyan-400" />
          <span className="text-sm font-bold text-slate-200">
            Segments Configuration ({state.seg.length})
          </span>
          <span className="text-xs text-slate-500 font-mono">
            Total {ledCount} LEDs
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={splitInTwo}
            className="px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white flex items-center gap-1.5"
            title="Split strip into 2 equal halves"
          >
            <SplitSquareVertical className="w-3.5 h-3.5 text-cyan-400" />
            Split in 2
          </button>
          <button
            onClick={splitInThree}
            className="px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white flex items-center gap-1.5"
            title="Split strip into 3 sections"
          >
            <SplitSquareVertical className="w-3.5 h-3.5 text-purple-400" />
            Split in 3
          </button>
          <button
            onClick={resetToOneSegment}
            className="px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white flex items-center gap-1.5"
            title="Reset to 1 full segment"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Unified
          </button>
          <button
            onClick={addSegment}
            className="px-3 py-1.5 text-xs font-bold rounded-lg bg-cyan-500 text-slate-950 hover:bg-cyan-400 flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
          >
            <Plus className="w-4 h-4" />
            Add Segment
          </button>
        </div>
      </div>

      {/* Segment Cards List */}
      <div className="space-y-4">
        {state.seg.map((seg) => {
          const isSelected = seg.sel;
          const count = Math.max(0, seg.stop - seg.start);

          return (
            <div
              key={seg.id}
              className={`rounded-2xl border p-5 transition-all ${
                isSelected
                  ? "bg-slate-900/95 border-cyan-400 shadow-xl shadow-cyan-950/40 ring-1 ring-cyan-400/50"
                  : "bg-slate-900/70 border-slate-800/90 hover:bg-slate-900 hover:border-slate-700"
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => updateSegment(seg.id, { on: !seg.on })}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                      seg.on
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm"
                        : "bg-slate-800 text-slate-500 border border-slate-700"
                    }`}
                    title={seg.on ? "Segment Power On" : "Segment Power Off"}
                  >
                    <Power className="w-4 h-4" />
                  </button>

                  <div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={seg.name || `Segment ${seg.id}`}
                        onChange={(e) => updateSegment(seg.id, { name: e.target.value })}
                        className="bg-transparent font-bold text-sm text-slate-100 hover:border-b border-cyan-400 focus:outline-none focus:border-b"
                      />
                      <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/70 border border-cyan-800/60 px-1.5 py-0.5 rounded">
                        ID: {seg.id}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono">
                      LEDs {seg.start} → {seg.stop} ({count} Total LEDs)
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSelectedSegment(seg.id)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? "bg-cyan-500 text-slate-950 border-cyan-400"
                        : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    {isSelected ? "Active Target" : "Select for Color/FX"}
                  </button>

                  {state.seg.length > 1 && (
                    <button
                      onClick={() => removeSegment(seg.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/30 transition-all"
                      title="Delete Segment"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Segment Parameters Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-3 border-t border-slate-800">
                {/* Start LED */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="block text-[10px] text-slate-400 font-mono uppercase">
                    Start LED
                  </label>
                  <input
                    type="number"
                    min="0"
                    max={ledCount - 1}
                    value={seg.start}
                    onChange={(e) =>
                      updateSegment(seg.id, {
                        start: Math.max(0, parseInt(e.target.value, 10) || 0),
                      })
                    }
                    className="w-full bg-transparent font-mono text-xs font-bold text-slate-100 focus:outline-none"
                  />
                </div>

                {/* Stop LED */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="block text-[10px] text-slate-400 font-mono uppercase">
                    Stop LED
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={ledCount}
                    value={seg.stop}
                    onChange={(e) =>
                      updateSegment(seg.id, {
                        stop: Math.min(ledCount, parseInt(e.target.value, 10) || 1),
                      })
                    }
                    className="w-full bg-transparent font-mono text-xs font-bold text-slate-100 focus:outline-none"
                  />
                </div>

                {/* Grouping */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="block text-[10px] text-slate-400 font-mono uppercase">
                    Grouping (grp)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="64"
                    value={seg.grp ?? 1}
                    onChange={(e) =>
                      updateSegment(seg.id, {
                        grp: Math.max(1, parseInt(e.target.value, 10) || 1),
                      })
                    }
                    className="w-full bg-transparent font-mono text-xs font-bold text-slate-100 focus:outline-none"
                  />
                </div>

                {/* Spacing */}
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="block text-[10px] text-slate-400 font-mono uppercase">
                    Spacing (spc)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="64"
                    value={seg.spc ?? 0}
                    onChange={(e) =>
                      updateSegment(seg.id, {
                        spc: Math.max(0, parseInt(e.target.value, 10) || 0),
                      })
                    }
                    className="w-full bg-transparent font-mono text-xs font-bold text-slate-100 focus:outline-none"
                  />
                </div>

                {/* Reverse toggle */}
                <button
                  onClick={() => updateSegment(seg.id, { rev: !seg.rev })}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    seg.rev
                      ? "bg-purple-950/50 border-purple-500/60 text-purple-300"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <div className="text-[10px] font-mono uppercase">Reverse (rev)</div>
                  <div className="text-xs font-bold mt-0.5">
                    {seg.rev ? "REVERSED" : "NORMAL"}
                  </div>
                </button>

                {/* Mirror toggle */}
                <button
                  onClick={() => updateSegment(seg.id, { mi: !seg.mi })}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    seg.mi
                      ? "bg-cyan-950/50 border-cyan-500/60 text-cyan-300"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <div className="text-[10px] font-mono uppercase">Mirror (mi)</div>
                  <div className="text-xs font-bold mt-0.5">
                    {seg.mi ? "MIRRORED" : "SINGLE"}
                  </div>
                </button>
              </div>

              {/* Segment Brightness */}
              <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center space-x-3">
                <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="text-xs font-mono text-slate-400 shrink-0">
                  Bri: {seg.bri ?? 255}
                </span>
                <input
                  type="range"
                  min="0"
                  max="255"
                  value={seg.bri ?? 255}
                  onChange={(e) =>
                    updateSegment(seg.id, { bri: parseInt(e.target.value, 10) })
                  }
                  className="flex-1 h-2 rounded-lg appearance-none cursor-pointer bg-slate-950 accent-cyan-400"
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
