"use client";

import React, { useState } from "react";
import { X, Plus, Wifi, Server, Check, AlertCircle, Loader2 } from "lucide-react";

interface AddDeviceModalProps {
  onClose: () => void;
  onDeviceAdded: () => void;
}

export function AddDeviceModal({ onClose, onDeviceAdded }: AddDeviceModalProps) {
  const [name, setName] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [isVirtual, setIsVirtual] = useState(true);
  const [ledCount, setLedCount] = useState(60);
  const [isMatrix, setIsMatrix] = useState(false);
  const [matrixWidth, setMatrixWidth] = useState(16);
  const [matrixHeight, setMatrixHeight] = useState(16);
  const [voltage, setVoltage] = useState(5);
  const [maxCurrentMa, setMaxCurrentMa] = useState(2000);

  const [testingPing, setTestingPing] = useState(false);
  const [pingResult, setPingResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleTestConnection = async () => {
    if (!ipAddress.trim()) {
      setPingResult({ success: false, message: "Please enter an IP address" });
      return;
    }

    setTestingPing(true);
    setPingResult(null);

    try {
      const res = await fetch("/api/wled/sync-real", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ip: ipAddress.trim(), action: "info" }),
      });

      const data = await res.json();
      if (res.ok && data.online) {
        setPingResult({
          success: true,
          message: `Connected! Device name: ${data.data?.name || "WLED"}, ${
            data.data?.leds?.count || "unknown"
          } LEDs found.`,
        });
        if (data.data?.name && !name) {
          setName(data.data.name);
        }
        if (data.data?.leds?.count) {
          setLedCount(data.data.leds.count);
        }
      } else {
        setPingResult({
          success: false,
          message: data.error || "Device not responding at this IP.",
        });
      }
    } catch {
      setPingResult({
        success: false,
        message: "Failed to communicate with device proxy.",
      });
    } finally {
      setTestingPing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    try {
      const totalLeds = isMatrix ? matrixWidth * matrixHeight : ledCount;
      const res = await fetch("/api/devices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          ipAddress: ipAddress.trim() || "virtual",
          isVirtual,
          ledCount: totalLeds,
          matrixWidth: isMatrix ? matrixWidth : 0,
          matrixHeight: isMatrix ? matrixHeight : 0,
          voltage,
          maxCurrentMa,
        }),
      });

      if (res.ok) {
        onDeviceAdded();
        onClose();
      }
    } catch (err) {
      console.error("Failed to add device:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center space-x-2">
            <Server className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold text-slate-100">Add WLED Controller</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Device Type Select */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setIsVirtual(true);
                setIpAddress("virtual");
              }}
              className={`p-3 rounded-xl border text-left transition-all ${
                isVirtual
                  ? "bg-slate-800 border-cyan-400 text-cyan-300 ring-1 ring-cyan-400/50"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800/50"
              }`}
            >
              <div className="text-xs font-bold mb-0.5">Virtual WLED Strip</div>
              <div className="text-[11px] text-slate-400">
                Simulated ESP with full visualizer
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsVirtual(false);
                setIpAddress("192.168.1.");
              }}
              className={`p-3 rounded-xl border text-left transition-all ${
                !isVirtual
                  ? "bg-slate-800 border-cyan-400 text-cyan-300 ring-1 ring-cyan-400/50"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800/50"
              }`}
            >
              <div className="text-xs font-bold mb-0.5">Physical WLED Device</div>
              <div className="text-[11px] text-slate-400">
                Connect real ESP8266/ESP32 via IP
              </div>
            </button>
          </div>

          {/* Device Name */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Device Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Gaming Setup Strip, Bedroom Ceiling, Matrix 16x16"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* Physical IP Address and Ping */}
          {!isVirtual && (
            <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>WLED Device IP or Hostname</span>
                <span className="text-[10px] text-slate-500">e.g. 192.168.1.150</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="192.168.1.150"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={testingPing}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1.5"
                >
                  {testingPing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Wifi className="w-3.5 h-3.5" />
                  )}
                  <span>Ping</span>
                </button>
              </div>

              {pingResult && (
                <div
                  className={`text-xs p-2 rounded-lg border flex items-center gap-2 ${
                    pingResult.success
                      ? "bg-emerald-950/40 border-emerald-500/40 text-emerald-300"
                      : "bg-rose-950/40 border-rose-500/40 text-rose-300"
                  }`}
                >
                  {pingResult.success ? (
                    <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  )}
                  <span>{pingResult.message}</span>
                </div>
              )}
            </div>
          )}

          {/* Matrix vs 1D Strip */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
            <span className="text-slate-300 font-medium">2D Matrix Panel Mode</span>
            <input
              type="checkbox"
              checked={isMatrix}
              onChange={(e) => setIsMatrix(e.target.checked)}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </div>

          {isMatrix ? (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Matrix Width (Columns)</label>
                <input
                  type="number"
                  min="4"
                  max="64"
                  value={matrixWidth}
                  onChange={(e) => setMatrixWidth(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Matrix Height (Rows)</label>
                <input
                  type="number"
                  min="4"
                  max="64"
                  value={matrixHeight}
                  onChange={(e) => setMatrixHeight(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              <label className="text-xs text-slate-400">LED Count (WS2812B / SK6812)</label>
              <input
                type="number"
                min="1"
                max="600"
                value={ledCount}
                onChange={(e) => setLedCount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
              />
            </div>
          )}

          {/* Voltage and Max Current */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs text-slate-400">Voltage (V)</label>
              <select
                value={voltage}
                onChange={(e) => setVoltage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value={5}>5V (Standard WS2812B)</option>
                <option value={12}>12V (WS2811 / WS2815)</option>
                <option value={24}>24V (High Density)</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-slate-400">Max Current (mA Limit)</label>
              <input
                type="number"
                min="500"
                max="20000"
                step="500"
                value={maxCurrentMa}
                onChange={(e) => setMaxCurrentMa(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
              />
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-3 border-t border-slate-800 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !name.trim()}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
            >
              {isSubmitting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Plus className="w-3.5 h-3.5" />
              )}
              <span>Create Controller</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
