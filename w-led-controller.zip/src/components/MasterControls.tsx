"use client";

import React from "react";
import { WledDeviceState } from "@/lib/wled-constants";
import { estimatePowerConsumption } from "@/lib/wled-helpers";
import {
  Power,
  Sun,
  Moon,
  Zap,
  Gauge,
  Sliders,
  ShieldAlert,
} from "lucide-react";

interface MasterControlsProps {
  state: WledDeviceState;
  ledCount: number;
  voltage: number;
  maxCurrentMa: number;
  onUpdateState: (patch: Partial<WledDeviceState>) => void;
}

export function MasterControls({
  state,
  ledCount,
  voltage,
  maxCurrentMa,
  onUpdateState,
}: MasterControlsProps) {
  const powerStats = estimatePowerConsumption(state, ledCount, voltage, maxCurrentMa);

  const togglePower = () => {
    onUpdateState({ on: !state.on });
  };

  const handleBrightnessChange = (val: number) => {
    onUpdateState({ bri: val });
  };

  const brightnessPercent = Math.round((state.bri / 255) * 100);

  const quickPresets = [
    { label: "Night", val: 12, percent: "5%" },
    { label: "25%", val: 64, percent: "25%" },
    { label: "50%", val: 128, percent: "50%" },
    { label: "75%", val: 191, percent: "75%" },
    { label: "100%", val: 255, percent: "100%" },
  ];

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl backdrop-blur-md">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
        {/* Left Column: Power Toggle */}
        <div className="lg:col-span-3 flex flex-row lg:flex-col items-center justify-between lg:justify-center p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <div className="flex items-center space-x-3 lg:mb-3">
            <button
              onClick={togglePower}
              className={`relative flex items-center justify-center w-14 h-14 rounded-full transition-all duration-300 shadow-lg ${
                state.on
                  ? "bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 shadow-emerald-500/30 scale-105 active:scale-95"
                  : "bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700 active:scale-95"
              }`}
              title={state.on ? "Turn Off" : "Turn On"}
            >
              <Power className={`w-7 h-7 ${state.on ? "stroke-[2.5]" : "stroke-2"}`} />
              {state.on && (
                <span className="absolute -inset-1 rounded-full bg-emerald-400/20 animate-pulse pointer-events-none" />
              )}
            </button>
            <div className="lg:hidden">
              <div className="text-sm font-bold text-slate-200">
                {state.on ? "State: ACTIVE" : "State: STANDBY"}
              </div>
              <div className="text-xs text-slate-400 font-mono">
                {state.on ? `${brightnessPercent}% Brightness` : "Power Off"}
              </div>
            </div>
          </div>
          <div className="hidden lg:block text-center">
            <span
              className={`inline-block px-2.5 py-0.5 text-xs font-semibold rounded-full border ${
                state.on
                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                  : "bg-slate-800 text-slate-400 border-slate-700"
              }`}
            >
              {state.on ? "SYSTEM ONLINE" : "STANDBY"}
            </span>
          </div>
        </div>

        {/* Center Column: Master Brightness Slider & Presets */}
        <div className="lg:col-span-6 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold">
            <div className="flex items-center space-x-1.5 text-slate-300">
              <Sun className="w-4 h-4 text-amber-400" />
              <span>MASTER BRIGHTNESS</span>
            </div>
            <div className="flex items-center space-x-2 font-mono">
              <span className="text-cyan-400 text-sm font-bold">{state.bri}</span>
              <span className="text-slate-500">/ 255</span>
              <span className="text-slate-400 text-xs bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                {brightnessPercent}%
              </span>
            </div>
          </div>

          {/* Slider bar with dynamic gradient */}
          <div className="relative flex items-center">
            <input
              type="range"
              min="0"
              max="255"
              value={state.bri}
              onChange={(e) => handleBrightnessChange(parseInt(e.target.value, 10))}
              className="w-full h-3 rounded-lg appearance-none cursor-pointer bg-slate-950 border border-slate-800 accent-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              style={{
                background: `linear-gradient(to right, #06b6d4 0%, #06b6d4 ${
                  (state.bri / 255) * 100
                }%, #0f172a ${(state.bri / 255) * 100}%, #0f172a 100%)`,
              }}
            />
          </div>

          {/* Quick Brightness Buttons */}
          <div className="grid grid-cols-5 gap-2 pt-1">
            {quickPresets.map((preset) => {
              const isActive = Math.abs(state.bri - preset.val) <= 5;
              return (
                <button
                  key={preset.label}
                  onClick={() => handleBrightnessChange(preset.val)}
                  className={`py-1 text-xs font-medium rounded-lg border transition-all text-center ${
                    isActive
                      ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold shadow-sm"
                      : "bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800/80 hover:text-slate-200"
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Electrical Telemetry Gauge */}
        <div className="lg:col-span-3 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-400">
            <span className="flex items-center space-x-1.5 text-slate-300">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>POWER METRICS</span>
            </span>
            <span className="font-mono text-cyan-400 text-xs font-bold">
              {powerStats.watts}W
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center text-xs">
            <div className="bg-slate-900 p-2 rounded-lg border border-slate-800/80">
              <div className="text-[10px] text-slate-500 uppercase tracking-wider">Current</div>
              <div className="font-mono font-bold text-slate-200">
                {powerStats.currentMa} <span className="text-[10px] text-slate-400">mA</span>
              </div>
            </div>
            <div className="bg-slate-900 p-2 rounded-lg border border-slate-800/80">
              <div className="text-[10px] text-slate-500 uppercase tracking-wider">Voltage</div>
              <div className="font-mono font-bold text-slate-200">
                {voltage} <span className="text-[10px] text-slate-400">V</span>
              </div>
            </div>
          </div>

          {/* Current limit progress bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>Limit: {maxCurrentMa}mA</span>
              <span className={powerStats.percentOfLimit > 85 ? "text-amber-400 font-bold" : ""}>
                {powerStats.percentOfLimit}%
              </span>
            </div>
            <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-300 ${
                  powerStats.percentOfLimit > 85
                    ? "bg-amber-500"
                    : powerStats.percentOfLimit > 60
                    ? "bg-cyan-400"
                    : "bg-emerald-400"
                }`}
                style={{ width: `${powerStats.percentOfLimit}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
