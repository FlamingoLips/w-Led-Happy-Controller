"use client";

import React from "react";
import { Device } from "@/db/schema";
import { WledDeviceState } from "@/lib/wled-constants";
import {
  Sliders,
  Server,
  Plus,
  Info,
  Radio,
  ChevronDown,
  Wifi,
  Sparkles,
} from "lucide-react";

interface NavbarProps {
  devices: Device[];
  activeDevice: Device | null;
  state: WledDeviceState;
  onSelectDevice: (device: Device) => void;
  onOpenAddModal: () => void;
  onOpenInfoModal: () => void;
}

export function Navbar({
  devices,
  activeDevice,
  state,
  onSelectDevice,
  onOpenAddModal,
  onOpenInfoModal,
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-emerald-400 text-slate-950 shadow-lg shadow-cyan-500/20">
            <Sliders className="w-5 h-5 stroke-[2.5]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse border-2 border-slate-950" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold tracking-tight text-white text-base">
                WLED<span className="text-cyan-400">.Studio</span>
              </span>
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-cyan-400 border border-slate-700 px-1.5 py-0.5 rounded font-bold">
                v0.14+
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">
              Fullstack Addressable LED Controller
            </p>
          </div>
        </div>

        {/* Center / Device Switcher */}
        <div className="flex items-center space-x-2">
          {devices.length > 0 && activeDevice && (
            <div className="relative group">
              <div className="flex items-center bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl px-3 py-1.5 transition-all cursor-pointer">
                <span
                  className={`w-2 h-2 rounded-full mr-2 ${
                    state.on ? "bg-emerald-400 shadow-[0_0_6px_#34d399]" : "bg-slate-600"
                  }`}
                />
                <select
                  value={activeDevice.id}
                  onChange={(e) => {
                    const found = devices.find((d) => d.id === Number(e.target.value));
                    if (found) onSelectDevice(found);
                  }}
                  className="bg-transparent text-xs font-bold text-slate-200 cursor-pointer focus:outline-none pr-4"
                >
                  {devices.map((d) => (
                    <option key={d.id} value={d.id} className="bg-slate-900 text-white">
                      {d.name} ({d.ledCount} LEDs)
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 pointer-events-none -ml-3" />
              </div>
            </div>
          )}

          {/* Add Device Button */}
          <button
            onClick={onOpenAddModal}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 hover:text-white transition-all shadow-sm"
            title="Add Device"
          >
            <Plus className="w-4 h-4 text-cyan-400" />
          </button>
        </div>

        {/* Right Info and Sync Badges */}
        <div className="flex items-center space-x-2">
          {activeDevice && (
            <button
              onClick={onOpenInfoModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 hover:text-white transition-all"
            >
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Diagnostics</span>
            </button>
          )}

          <div className="hidden md:flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-400">
            <Radio className="w-3 h-3 text-emerald-400" />
            <span>UDP: {state.udpn?.send || state.udpn?.recv ? "ACTIVE" : "STANDBY"}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
