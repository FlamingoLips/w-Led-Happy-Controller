import { NextResponse } from "next/server";
import { db } from "@/db";
import { devices } from "@/db/schema";
import { ensureInitialData } from "@/lib/seed-data";
import { createDefaultState } from "@/lib/wled-helpers";

export async function GET() {
  try {
    let allDevices = await db.select().from(devices).orderBy(devices.id);
    if (allDevices.length === 0) {
      allDevices = await ensureInitialData();
    }
    return NextResponse.json(allDevices);
  } catch (err: unknown) {
    console.error("Error fetching devices:", err);
    return NextResponse.json({ error: "Failed to fetch devices" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      name,
      ipAddress = "virtual",
      isVirtual = true,
      ledCount = 60,
      matrixWidth = 0,
      matrixHeight = 0,
      voltage = 5,
      maxCurrentMa = 2000,
      brightness = 180,
    } = body;

    if (!name || typeof name !== "string") {
      return NextResponse.json({ error: "Device name is required" }, { status: 400 });
    }

    const defaultState = createDefaultState(Number(ledCount) || 60);

    const [newDevice] = await db
      .insert(devices)
      .values({
        name,
        ipAddress,
        isVirtual: Boolean(isVirtual),
        ledCount: Number(ledCount) || 60,
        matrixWidth: Number(matrixWidth) || 0,
        matrixHeight: Number(matrixHeight) || 0,
        voltage: Number(voltage) || 5,
        maxCurrentMa: Number(maxCurrentMa) || 2000,
        power: true,
        brightness: Number(brightness) || 180,
        stateJson: JSON.stringify(defaultState),
      })
      .returning();

    return NextResponse.json(newDevice, { status: 201 });
  } catch (err: unknown) {
    console.error("Error creating device:", err);
    return NextResponse.json({ error: "Failed to create device" }, { status: 500 });
  }
}
