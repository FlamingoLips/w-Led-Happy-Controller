import { NextResponse } from "next/server";
import { db } from "@/db";
import { devices } from "@/db/schema";
import { eq } from "drizzle-orm";
import { WledDeviceState, WledSegmentState } from "@/lib/wled-constants";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const deviceId = parseInt(id, 10);
    if (isNaN(deviceId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const [device] = await db.select().from(devices).where(eq(devices.id, deviceId)).limit(1);
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    const state: WledDeviceState = JSON.parse(device.stateJson);
    return NextResponse.json(state);
  } catch (err: unknown) {
    console.error("Error reading device state:", err);
    return NextResponse.json({ error: "Failed to read state" }, { status: 500 });
  }
}

export async function POST(req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const deviceId = parseInt(id, 10);
    if (isNaN(deviceId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const [device] = await db.select().from(devices).where(eq(devices.id, deviceId)).limit(1);
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    const patch = await req.json();
    const currentState: WledDeviceState = JSON.parse(device.stateJson);

    // Deep merge patch into currentState
    if (patch.on !== undefined) currentState.on = Boolean(patch.on);
    if (patch.bri !== undefined) currentState.bri = Math.max(0, Math.min(255, Number(patch.bri)));
    if (patch.transition !== undefined) currentState.transition = Number(patch.transition);
    if (patch.ps !== undefined) currentState.ps = Number(patch.ps);
    if (patch.pl !== undefined) currentState.pl = Number(patch.pl);

    if (patch.nl) {
      currentState.nl = { ...currentState.nl, ...patch.nl };
    }
    if (patch.udpn) {
      currentState.udpn = { ...currentState.udpn, ...patch.udpn };
    }

    // Merge segment updates
    if (Array.isArray(patch.seg)) {
      // If single segment object or array of segments
      patch.seg.forEach((newSeg: Partial<WledSegmentState>, index: number) => {
        const targetId = newSeg.id !== undefined ? newSeg.id : index;
        const existingIdx = currentState.seg.findIndex((s) => s.id === targetId);

        if (existingIdx !== -1) {
          currentState.seg[existingIdx] = {
            ...currentState.seg[existingIdx],
            ...newSeg,
            // Preserve col if partially provided
            col: newSeg.col ? newSeg.col : currentState.seg[existingIdx].col,
          };
        } else if (newSeg.start !== undefined && newSeg.stop !== undefined) {
          currentState.seg.push({
            id: targetId,
            start: newSeg.start,
            stop: newSeg.stop,
            len: newSeg.stop - newSeg.start,
            grp: newSeg.grp ?? 1,
            spc: newSeg.spc ?? 0,
            of: newSeg.of ?? 0,
            on: newSeg.on ?? true,
            bri: newSeg.bri ?? 255,
            col: newSeg.col ?? [[255, 255, 255, 0]],
            fx: newSeg.fx ?? 0,
            sx: newSeg.sx ?? 128,
            ix: newSeg.ix ?? 128,
            pal: newSeg.pal ?? 0,
            sel: newSeg.sel ?? true,
            rev: newSeg.rev ?? false,
            mi: newSeg.mi ?? false,
            name: newSeg.name ?? `Segment ${targetId}`,
          });
        }
      });
    }

    // Save updated state into device
    const [updated] = await db
      .update(devices)
      .set({
        power: currentState.on,
        brightness: currentState.bri,
        stateJson: JSON.stringify(currentState),
        updatedAt: new Date(),
      })
      .where(eq(devices.id, deviceId))
      .returning();

    return NextResponse.json({ success: true, device: updated, state: currentState });
  } catch (err: unknown) {
    console.error("Error setting device state:", err);
    return NextResponse.json({ error: "Failed to update state" }, { status: 500 });
  }
}
