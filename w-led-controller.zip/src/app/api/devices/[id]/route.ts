import { NextResponse } from "next/server";
import { db } from "@/db";
import { devices } from "@/db/schema";
import { eq } from "drizzle-orm";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const deviceId = parseInt(id, 10);
    if (isNaN(deviceId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const [device] = await db.select().from(devices).where(eq(devices.id, deviceId)).limit(1);
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    return NextResponse.json(device);
  } catch (err: unknown) {
    console.error("Error fetching device:", err);
    return NextResponse.json({ error: "Failed to fetch device" }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const deviceId = parseInt(id, 10);
    if (isNaN(deviceId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const body = await req.json();
    const updateData: Partial<typeof devices.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (body.name !== undefined) updateData.name = body.name;
    if (body.ipAddress !== undefined) updateData.ipAddress = body.ipAddress;
    if (body.isVirtual !== undefined) updateData.isVirtual = body.isVirtual;
    if (body.ledCount !== undefined) updateData.ledCount = Number(body.ledCount);
    if (body.matrixWidth !== undefined) updateData.matrixWidth = Number(body.matrixWidth);
    if (body.matrixHeight !== undefined) updateData.matrixHeight = Number(body.matrixHeight);
    if (body.voltage !== undefined) updateData.voltage = Number(body.voltage);
    if (body.maxCurrentMa !== undefined) updateData.maxCurrentMa = Number(body.maxCurrentMa);
    if (body.power !== undefined) updateData.power = Boolean(body.power);
    if (body.brightness !== undefined) updateData.brightness = Number(body.brightness);
    if (body.stateJson !== undefined) {
      updateData.stateJson =
        typeof body.stateJson === "string" ? body.stateJson : JSON.stringify(body.stateJson);
    }

    const [updated] = await db
      .update(devices)
      .set(updateData)
      .where(eq(devices.id, deviceId))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    return NextResponse.json(updated);
  } catch (err: unknown) {
    console.error("Error updating device:", err);
    return NextResponse.json({ error: "Failed to update device" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const deviceId = parseInt(id, 10);
    if (isNaN(deviceId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    await db.delete(devices).where(eq(devices.id, deviceId));
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error("Error deleting device:", err);
    return NextResponse.json({ error: "Failed to delete device" }, { status: 500 });
  }
}
