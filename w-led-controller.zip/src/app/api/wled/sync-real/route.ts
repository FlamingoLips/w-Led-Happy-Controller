import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { ip, payload, action = "state" } = await req.json();

    if (!ip) {
      return NextResponse.json({ error: "IP address is required" }, { status: 400 });
    }

    const cleanIp = ip.replace(/^https?:\/\//, "").replace(/\/$/, "");
    const targetUrl = `http://${cleanIp}/json/${action === "info" ? "info" : "state"}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);

    try {
      const fetchOpts: RequestInit = {
        signal: controller.signal,
        headers: { "Content-Type": "application/json" },
      };

      if (payload) {
        fetchOpts.method = "POST";
        fetchOpts.body = JSON.stringify(payload);
      } else {
        fetchOpts.method = "GET";
      }

      const res = await fetch(targetUrl, fetchOpts);
      clearTimeout(timeout);

      if (!res.ok) {
        return NextResponse.json(
          { error: `Device responded with HTTP ${res.status}` },
          { status: res.status }
        );
      }

      const data = await res.json();
      return NextResponse.json({ success: true, data, online: true });
    } catch (fetchError: unknown) {
      clearTimeout(timeout);
      const isAbort = (fetchError as { name?: string })?.name === "AbortError";
      return NextResponse.json(
        {
          online: false,
          error: isAbort
            ? `Connection timed out connecting to http://${cleanIp}`
            : `Could not reach http://${cleanIp}: device might be offline or unreachable on this network.`,
        },
        { status: 504 }
      );
    }
  } catch (err: unknown) {
    console.error("WLED proxy error:", err);
    return NextResponse.json({ error: "Proxy server error" }, { status: 500 });
  }
}
