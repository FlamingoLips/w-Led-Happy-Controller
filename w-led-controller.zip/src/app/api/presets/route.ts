import { NextResponse } from "next/server";
import { db } from "@/db";
import { presets } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const deviceIdParam = searchParams.get("deviceId");

    let allPresets;
    if (deviceIdParam) {
      allPresets = await db
        .select()
        .from(presets)
        .where(eq(presets.deviceId, parseInt(deviceIdParam, 10)))
        .orderBy(presets.id);
    } else {
      allPresets = await db.select().from(presets).orderBy(presets.id);
    }

    return NextResponse.json(allPresets);
  } catch (err: unknown) {
    console.error("Error fetching presets:", err);
    return NextResponse.json({ error: "Failed to fetch presets" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { deviceId, name, stateData, quickLoadKey } = body;

    if (!name || !stateData) {
      return NextResponse.json({ error: "Name and stateData are required" }, { status: 400 });
    }

    const [created] = await db
      .insert(presets)
      .values({
        deviceId: deviceId ? Number(deviceId) : null,
        name,
        quickLoadKey: quickLoadKey ? Number(quickLoadKey) : null,
        stateData: typeof stateData === "string" ? stateData : JSON.stringify(stateData),
      })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch (err: unknown) {
    console.error("Error creating preset:", err);
    return NextResponse.json({ error: "Failed to create preset" }, { status: 500 });
  }
}
