import { NextResponse } from "next/server";
import { db } from "@/db";
import { presets } from "@/db/schema";
import { eq } from "drizzle-orm";

interface Params {
  params: Promise<{ id: string }>;
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const presetId = parseInt(id, 10);
    if (isNaN(presetId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    await db.delete(presets).where(eq(presets.id, presetId));
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error("Error deleting preset:", err);
    return NextResponse.json({ error: "Failed to delete preset" }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    const { id } = await params;
    const presetId = parseInt(id, 10);
    if (isNaN(presetId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const body = await req.json();
    const updateData: Partial<typeof presets.$inferInsert> = {};
    if (body.name !== undefined) updateData.name = body.name;
    if (body.quickLoadKey !== undefined) updateData.quickLoadKey = body.quickLoadKey;
    if (body.stateData !== undefined) {
      updateData.stateData =
        typeof body.stateData === "string" ? body.stateData : JSON.stringify(body.stateData);
    }

    const [updated] = await db
      .update(presets)
      .set(updateData)
      .where(eq(presets.id, presetId))
      .returning();

    return NextResponse.json(updated);
  } catch (err: unknown) {
    console.error("Error updating preset:", err);
    return NextResponse.json({ error: "Failed to update preset" }, { status: 500 });
  }
}
