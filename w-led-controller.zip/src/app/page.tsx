"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Device } from "@/db/schema";
import { WledDeviceState } from "@/lib/wled-constants";
import { createDefaultState } from "@/lib/wled-helpers";
import { Navbar } from "@/components/Navbar";
import { VisualizerCanvas } from "@/components/VisualizerCanvas";
import { MasterControls } from "@/components/MasterControls";
import { ColorTab } from "@/components/ColorTab";
import { EffectsTab } from "@/components/EffectsTab";
import { SegmentsTab } from "@/components/SegmentsTab";
import { PresetsTab, PresetItem } from "@/components/PresetsTab";
import { AutomationTab } from "@/components/AutomationTab";
import { DeviceInfoModal } from "@/components/DeviceInfoModal";
import { AddDeviceModal } from "@/components/AddDeviceModal";
import {
  Palette,
  Sparkles,
  Layers,
  Bookmark,
  Moon,
  Loader2,
  RefreshCw,
} from "lucide-react";

export default function WledControllerPage() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [activeDevice, setActiveDevice] = useState<Device | null>(null);
  const [state, setState] = useState<WledDeviceState>(() => createDefaultState(60));
  const [presetsList, setPresetsList] = useState<PresetItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Active Tab: "colors" | "effects" | "segments" | "presets" | "automation"
  const [activeTab, setActiveTab] = useState<
    "colors" | "effects" | "segments" | "presets" | "automation"
  >("colors");

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);

  // Fetch all devices from API
  const fetchDevices = useCallback(async () => {
    try {
      const res = await fetch("/api/devices");
      if (res.ok) {
        const data: Device[] = await res.json();
        setDevices(data);
        if (data.length > 0) {
          // If no active device, pick the first one
          setActiveDevice((current) => {
            if (!current) {
              const first = data[0];
              try {
                setState(JSON.parse(first.stateJson));
              } catch {}
              return first;
            }
            const updated = data.find((d) => d.id === current.id);
            return updated || data[0];
          });
        }
      }
    } catch (err) {
      console.error("Failed to load devices:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch presets
  const fetchPresets = useCallback(async () => {
    try {
      const res = await fetch("/api/presets");
      if (res.ok) {
        const data = await res.json();
        setPresetsList(data);
      }
    } catch (err) {
      console.error("Failed to load presets:", err);
    }
  }, []);

  useEffect(() => {
    fetchDevices();
    fetchPresets();
  }, [fetchDevices, fetchPresets]);

  // Handle switching active device
  const handleSelectDevice = (device: Device) => {
    setActiveDevice(device);
    try {
      const parsed: WledDeviceState = JSON.parse(device.stateJson);
      setState(parsed);
    } catch {
      setState(createDefaultState(device.ledCount));
    }
  };

  // State update dispatcher: updates local state immediately, then debounced/synced to API
  const handleUpdateState = useCallback(
    async (patch: Partial<WledDeviceState>) => {
      if (!activeDevice) return;

      const newState: WledDeviceState = {
        ...state,
        ...patch,
        seg: patch.seg ? patch.seg : state.seg,
      };

      // Optimistic update
      setState(newState);

      try {
        await fetch(`/api/devices/${activeDevice.id}/state`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patch),
        });
      } catch (err) {
        console.error("Failed to sync state with backend:", err);
      }
    },
    [activeDevice, state]
  );

  const handleLoadPreset = (presetState: WledDeviceState) => {
    handleUpdateState(presetState);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300">
        <Loader2 className="w-10 h-10 animate-spin text-cyan-400 mb-4" />
        <p className="text-sm font-mono tracking-wider">
          Initializing WLED Controller Hub...
        </p>
      </div>
    );
  }

  const ledCount = activeDevice?.ledCount || 60;
  const matrixWidth = activeDevice?.matrixWidth || 0;
  const matrixHeight = activeDevice?.matrixHeight || 0;

  return (
    <div className="min-h-screen bg-[#070a0f] text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        devices={devices}
        activeDevice={activeDevice}
        state={state}
        onSelectDevice={handleSelectDevice}
        onOpenAddModal={() => setShowAddModal(true)}
        onOpenInfoModal={() => setShowInfoModal(true)}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Real-time LED Strip Visualizer Preview */}
        <VisualizerCanvas
          state={state}
          ledCount={ledCount}
          matrixWidth={matrixWidth}
          matrixHeight={matrixHeight}
        />

        {/* Master Power, Master Brightness, and Power Gauges */}
        <MasterControls
          state={state}
          ledCount={ledCount}
          voltage={activeDevice?.voltage || 5}
          maxCurrentMa={activeDevice?.maxCurrentMa || 2000}
          onUpdateState={handleUpdateState}
        />

        {/* Navigation Tabs Bar */}
        <div className="flex border-b border-slate-800 space-x-1 sm:space-x-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveTab("colors")}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === "colors"
                ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>Colors & Palettes</span>
          </button>

          <button
            onClick={() => setActiveTab("effects")}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === "effects"
                ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Effects ({state.seg[0]?.fx ?? 0})</span>
          </button>

          <button
            onClick={() => setActiveTab("segments")}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === "segments"
                ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Segments ({state.seg.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("presets")}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === "presets"
                ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Presets & Playlist</span>
          </button>

          <button
            onClick={() => setActiveTab("automation")}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === "automation"
                ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
            }`}
          >
            <Moon className="w-4 h-4" />
            <span>Nightlight & API</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="pt-2">
          {activeTab === "colors" && (
            <ColorTab state={state} onUpdateState={handleUpdateState} />
          )}

          {activeTab === "effects" && (
            <EffectsTab state={state} onUpdateState={handleUpdateState} />
          )}

          {activeTab === "segments" && (
            <SegmentsTab
              state={state}
              ledCount={ledCount}
              onUpdateState={handleUpdateState}
            />
          )}

          {activeTab === "presets" && activeDevice && (
            <PresetsTab
              deviceId={activeDevice.id}
              state={state}
              presetsList={presetsList}
              onLoadPreset={handleLoadPreset}
              onRefreshPresets={fetchPresets}
            />
          )}

          {activeTab === "automation" && (
            <AutomationTab state={state} onUpdateState={handleUpdateState} />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900/80 bg-slate-950/60 py-6 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            WLED Fullstack Controller &bull; Compatible with WS2812B, WS2811, SK6812 RGBW
          </div>
          <div className="text-slate-400">
            Node: {activeDevice?.name} &bull; {activeDevice?.ipAddress}
          </div>
        </div>
      </footer>

      {/* Modals */}
      {showAddModal && (
        <AddDeviceModal
          onClose={() => setShowAddModal(false)}
          onDeviceAdded={fetchDevices}
        />
      )}

      {showInfoModal && activeDevice && (
        <DeviceInfoModal
          device={activeDevice}
          state={state}
          onClose={() => setShowInfoModal(false)}
        />
      )}
    </div>
  );
}
