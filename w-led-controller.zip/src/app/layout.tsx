import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "WLED Studio — NeoPixel & Addressable LED Controller",
  description:
    "Fullstack WLED interface for WS2812B, WS2811, and SK6812 LED strips and matrices. Real-time visualizer, effects, palettes, segments, and presets.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#070a0f] text-slate-100 antialiased selection:bg-cyan-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
