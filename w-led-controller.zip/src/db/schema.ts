import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ipAddress: text("ip_address").notNull().default("virtual"),
  isVirtual: boolean("is_virtual").notNull().default(true),
  ledCount: integer("led_count").notNull().default(60),
  matrixWidth: integer("matrix_width").default(0),
  matrixHeight: integer("matrix_height").default(0),
  voltage: integer("voltage").notNull().default(5),
  maxCurrentMa: integer("max_current_ma").notNull().default(2000),
  power: boolean("power").notNull().default(true),
  brightness: integer("brightness").notNull().default(128),
  stateJson: text("state_json").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const presets = pgTable("presets", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").references(() => devices.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  quickLoadKey: integer("quick_load_key"),
  stateData: text("state_data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  items: text("items").notNull(), // JSON string array of { presetId, durationSec, transitionSec }
  repeat: boolean("repeat").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").references(() => devices.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  time: text("time").notNull(), // "22:30"
  action: text("action").notNull(), // "turn_off", "load_preset", "nightlight"
  presetId: integer("preset_id"),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Device = typeof devices.$inferSelect;
export type NewDevice = typeof devices.$inferInsert;
export type Preset = typeof presets.$inferSelect;
export type Playlist = typeof playlists.$inferSelect;
export type Schedule = typeof schedules.$inferSelect;
