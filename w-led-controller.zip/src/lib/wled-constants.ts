// WLED Effects, Palettes, and Default Configurations (Compatible with WLED v0.14+)

export interface WledEffect {
  id: number;
  name: string;
  category: "Classic" | "Nature & Fire" | "Dynamic" | "Party & Rave" | "Ambient" | "Patterns";
  description: string;
}

export const WLED_EFFECTS: WledEffect[] = [
  { id: 0, name: "Solid", category: "Classic", description: "Steady uniform illumination" },
  { id: 1, name: "Blink", category: "Classic", description: "Blinks on and off" },
  { id: 2, name: "Breathe", category: "Classic", description: "Smooth breathing brightness cycle" },
  { id: 3, name: "Wipe", category: "Dynamic", description: "Color wipe across the strip" },
  { id: 4, name: "Dual Wipe", category: "Dynamic", description: "Wipes from both ends toward center" },
  { id: 5, name: "Colorloop", category: "Dynamic", description: "Continuous spectrum cycle across strip" },
  { id: 6, name: "Rainbow", category: "Dynamic", description: "Classic scrolling rainbow spectrum" },
  { id: 7, name: "Rainbow Runner", category: "Dynamic", description: "Fast scrolling rainbow comet dots" },
  { id: 8, name: "Fire 2012", category: "Nature & Fire", description: "Realistic flickering campfire flames" },
  { id: 9, name: "Candle", category: "Nature & Fire", description: "Soft flickering candle flame" },
  { id: 10, name: "Police / Scanner", category: "Party & Rave", description: "Alternating red & blue emergency flashers" },
  { id: 11, name: "Twinkle", category: "Ambient", description: "Gentle sparkling night stars" },
  { id: 12, name: "Sparkle", category: "Ambient", description: "Occasional bright flashes of light" },
  { id: 13, name: "Aurora", category: "Nature & Fire", description: "Mesmerizing northern lights wave" },
  { id: 14, name: "Matrix Rain", category: "Patterns", description: "Digital cyber green rain stream" },
  { id: 15, name: "Chase", category: "Dynamic", description: "Dots running along the strip" },
  { id: 16, name: "Android", category: "Dynamic", description: "Smooth cyber chase glow" },
  { id: 17, name: "Strobe", category: "Party & Rave", description: "High-frequency strobe flash" },
  { id: 18, name: "Running", category: "Dynamic", description: "Continuously flowing stream" },
  { id: 19, name: "Waves", category: "Nature & Fire", description: "Oceanic harmonic wave motion" },
  { id: 20, name: "Gradient", category: "Ambient", description: "Smooth linear transition between colors" },
  { id: 21, name: "Juggle", category: "Dynamic", description: "Multiple glowing balls bouncing in sequence" },
  { id: 22, name: "Bouncing Balls", category: "Dynamic", description: "Simulated gravity bouncing colored orbs" },
  { id: 23, name: "Fireworks", category: "Party & Rave", description: "Colorful exploding rocket bursts" },
  { id: 24, name: "Lighthouse", category: "Ambient", description: "Sweeping beacon spotlight" },
  { id: 25, name: "Heartbeat", category: "Ambient", description: "Rhythmic human pulse glow" },
  { id: 26, name: "Pacman", category: "Patterns", description: "Retro arcade chaser" },
  { id: 27, name: "Plasma", category: "Dynamic", description: "Sci-fi swirling energy distortion" },
  { id: 28, name: "Meteor", category: "Dynamic", description: "Falling meteor streak with fading tail" },
  { id: 29, name: "Popcorn", category: "Dynamic", description: "Random bursting sparks" },
  { id: 30, name: "Sinelon", category: "Dynamic", description: "Sine-wave oscillating point of light" },
  { id: 31, name: "Sunset Drift", category: "Ambient", description: "Calm evening twilight glow" },
  { id: 32, name: "Cyber Stride", category: "Party & Rave", description: "High-tempo cyberpunk scanner" },
];

export interface WledPalette {
  id: number;
  name: string;
  colors: string[]; // hex array
}

export const WLED_PALETTES: WledPalette[] = [
  { id: 0, name: "Default (Slot Colors)", colors: ["#FF0055", "#00FFCC", "#FFB703"] },
  { id: 1, name: "Rainbow", colors: ["#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#0000FF", "#4B0082", "#9400D3"] },
  { id: 2, name: "Party", colors: ["#5500AB", "#84007C", "#B5004B", "#E5001B", "#E81700", "#B84700", "#AB7700"] },
  { id: 3, name: "Fire & Flame", colors: ["#000000", "#440000", "#880000", "#FF2200", "#FFAA00", "#FFFF88"] },
  { id: 4, name: "Ocean Breeze", colors: ["#001133", "#004488", "#0088CC", "#00CCEE", "#44FFEE", "#FFFFFF"] },
  { id: 5, name: "Forest Canopy", colors: ["#002200", "#005500", "#008822", "#33BB44", "#88FF66", "#CCFFAA"] },
  { id: 6, name: "Sunset Horizon", colors: ["#1B0033", "#4A005B", "#850066", "#B9284D", "#E36128", "#FFB600"] },
  { id: 7, name: "Lava Flow", colors: ["#110000", "#440000", "#880000", "#DD2200", "#FF6600", "#FFAA00"] },
  { id: 8, name: "Aurora Borealis", colors: ["#051821", "#1A4645", "#266867", "#3B8686", "#79BD9A", "#A8DBA8"] },
  { id: 9, name: "Cyberpunk 2077", colors: ["#FF0055", "#7928CA", "#00F0FF", "#FFE600", "#001122"] },
  { id: 10, name: "Synthwave", colors: ["#241734", "#2E2157", "#FD3A69", "#FECD1A", "#03C4A1"] },
  { id: 11, name: "Vaporwave Pastel", colors: ["#FF71CE", "#01CDFE", "#05FFA1", "#B967FF", "#FFFB96"] },
  { id: 12, name: "Deep Amber Candle", colors: ["#1A0800", "#521A00", "#993D00", "#DE6700", "#FF9E2C", "#FFD27F"] },
  { id: 13, name: "Halloween Spooky", colors: ["#1A002C", "#380062", "#FF5100", "#FF9500", "#18B800"] },
  { id: 14, name: "Christmas Festive", colors: ["#0B3B0B", "#1C6B1C", "#990000", "#E60000", "#FFCC00", "#FFFFFF"] },
  { id: 15, name: "Citrus Punch", colors: ["#E63946", "#F1FAEE", "#A8DADC", "#457B9D", "#1D3557"] },
  { id: 16, name: "Cloud White Tones", colors: ["#1E293B", "#475569", "#94A3B8", "#CBD5E1", "#F8FAFC"] },
  { id: 17, name: "Neon Matrix", colors: ["#001100", "#004400", "#00AA00", "#00FF44", "#AAFFAA"] },
];

export const QUICK_COLORS = [
  { name: "Pure Red", rgb: [255, 0, 0], hex: "#FF0000" },
  { name: "Vibrant Orange", rgb: [255, 100, 0], hex: "#FF6400" },
  { name: "Gold Amber", rgb: [255, 180, 0], hex: "#FFB400" },
  { name: "Sunny Yellow", rgb: [255, 230, 0], hex: "#FFE600" },
  { name: "Lime Green", rgb: [50, 255, 0], hex: "#32FF00" },
  { name: "Emerald Green", rgb: [0, 255, 100], hex: "#00FF64" },
  { name: "Cyan Teal", rgb: [0, 240, 255], hex: "#00F0FF" },
  { name: "Sky Blue", rgb: [0, 130, 255], hex: "#0082FF" },
  { name: "Electric Blue", rgb: [0, 50, 255], hex: "#0032FF" },
  { name: "Deep Indigo", rgb: [70, 0, 255], hex: "#4600FF" },
  { name: "Cyber Purple", rgb: [160, 0, 255], hex: "#A000FF" },
  { name: "Magenta Pink", rgb: [255, 0, 180], hex: "#FF00B4" },
  { name: "Warm White (2700K)", rgb: [255, 180, 107], hex: "#FFB46B" },
  { name: "Soft White (3000K)", rgb: [255, 205, 148], hex: "#FFCD94" },
  { name: "Neutral White (4000K)", rgb: [255, 238, 214], hex: "#FFEED6" },
  { name: "Daylight White (5500K)", rgb: [255, 250, 244], hex: "#FFFAF4" },
  { name: "Cool White (6500K)", rgb: [230, 240, 255], hex: "#E6F0FF" },
];

export interface WledSegmentState {
  id: number;
  start: number;
  stop: number;
  len: number;
  grp: number; // grouping
  spc: number; // spacing
  of: number;  // offset
  on: boolean;
  bri: number;
  col: number[][]; // [[R, G, B, W?], [R, G, B, W?], [R, G, B, W?]]
  fx: number;  // effect id
  sx: number;  // speed 0-255
  ix: number;  // intensity 0-255
  pal: number; // palette id
  sel: boolean; // selected in segment manager
  rev: boolean; // reverse
  mi: boolean;  // mirror
  name?: string;
}

export interface WledDeviceState {
  on: boolean;
  bri: number;
  transition: number; // in 100ms
  ps: number; // active preset id (-1 for none)
  pl: number; // active playlist id (-1 for none)
  nl: {
    on: boolean;
    dur: number; // minutes
    mode: number; // 0=instant, 1=fade, 2=color fade, 3=sunrise
    tbri: number; // target brightness
    rem: number;  // remaining seconds
  };
  udpn: {
    send: boolean;
    recv: boolean;
  };
  lor: number;
  mainseg: number;
  seg: WledSegmentState[];
}

export interface WledDeviceInfo {
  ver: string;
  vid: number;
  leds: {
    count: number;
    pwr: number; // mW
    fps: number;
    maxpwr: number;
    maxseg: number;
    pin: number[];
  };
  name: string;
  udpport: number;
  live: boolean;
  fxcount: number;
  palcount: number;
  arch: string;
  core: string;
  freeheap: number;
  uptime: number; // seconds
  opt: number;
  brand: string;
  product: string;
  mac: string;
  ip: string;
  rssi: number;
  signalQuality: number;
}
