import { db } from "@/db";
import { devices, presets } from "@/db/schema";
import { WledDeviceState } from "./wled-constants";

export async function ensureInitialData() {
  const existingDevices = await db.select().from(devices);
  if (existingDevices.length > 0) {
    return existingDevices;
  }

  // Seed Default Device 1: Battlestation Desk Strip (WS2812B 120 LEDs)
  const deskState: WledDeviceState = {
    on: true,
    bri: 200,
    transition: 7,
    ps: 1,
    pl: -1,
    nl: { on: false, dur: 15, mode: 1, tbri: 0, rem: 0 },
    udpn: { send: true, recv: true },
    lor: 0,
    mainseg: 0,
    seg: [
      {
        id: 0,
        start: 0,
        stop: 60,
        len: 60,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 240,
        col: [
          [255, 0, 100, 0],   // Neon Pink
          [0, 240, 255, 0],   // Cyber Cyan
          [255, 180, 0, 0],   // Gold
        ],
        fx: 6, // Rainbow
        sx: 140,
        ix: 190,
        pal: 9, // Cyberpunk
        sel: true,
        rev: false,
        mi: false,
        name: "Desk Left & Rear",
      },
      {
        id: 1,
        start: 60,
        stop: 120,
        len: 60,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 220,
        col: [
          [0, 240, 255, 0],
          [160, 0, 255, 0],
          [255, 0, 100, 0],
        ],
        fx: 13, // Aurora
        sx: 90,
        ix: 170,
        pal: 10, // Synthwave
        sel: false,
        rev: false,
        mi: false,
        name: "Desk Right Wing",
      },
    ],
  };

  // Seed Default Device 2: Living Room TV Bias Backlight (60 LEDs)
  const tvState: WledDeviceState = {
    on: true,
    bri: 160,
    transition: 7,
    ps: 2,
    pl: -1,
    nl: { on: false, dur: 30, mode: 1, tbri: 0, rem: 0 },
    udpn: { send: false, recv: true },
    lor: 0,
    mainseg: 0,
    seg: [
      {
        id: 0,
        start: 0,
        stop: 60,
        len: 60,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 180,
        col: [
          [255, 120, 20, 0],
          [255, 60, 0, 0],
          [255, 200, 50, 0],
        ],
        fx: 8, // Fire 2012
        sx: 110,
        ix: 200,
        pal: 3, // Fire
        sel: true,
        rev: false,
        mi: true,
        name: "Ambilight Perimeter",
      },
    ],
  };

  // Seed Default Device 3: 16x16 Pixel Art Matrix Panel (256 LEDs)
  const matrixState: WledDeviceState = {
    on: true,
    bri: 175,
    transition: 5,
    ps: 3,
    pl: -1,
    nl: { on: false, dur: 10, mode: 1, tbri: 0, rem: 0 },
    udpn: { send: false, recv: false },
    lor: 0,
    mainseg: 0,
    seg: [
      {
        id: 0,
        start: 0,
        stop: 256,
        len: 256,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 255,
        col: [
          [0, 255, 70, 0],   // Terminal Green
          [0, 100, 20, 0],
          [200, 255, 200, 0],
        ],
        fx: 14, // Matrix Rain
        sx: 160,
        ix: 220,
        pal: 17, // Neon Matrix
        sel: true,
        rev: false,
        mi: false,
        name: "Matrix Display Area",
      },
    ],
  };

  // Seed Default Device 4: Kitchen Under-Cabinet Warm Glow (80 LEDs)
  const kitchenState: WledDeviceState = {
    on: true,
    bri: 220,
    transition: 10,
    ps: 4,
    pl: -1,
    nl: { on: false, dur: 20, mode: 1, tbri: 10, rem: 0 },
    udpn: { send: false, recv: false },
    lor: 0,
    mainseg: 0,
    seg: [
      {
        id: 0,
        start: 0,
        stop: 80,
        len: 80,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 255,
        col: [
          [255, 180, 107, 255], // Warm 2700K White
          [255, 210, 150, 200],
          [255, 140, 50, 100],
        ],
        fx: 2, // Breathe
        sx: 45,
        ix: 110,
        pal: 12, // Amber Candle
        sel: true,
        rev: false,
        mi: false,
        name: "Under Cabinet Strip",
      },
    ],
  };

  const inserted = await db
    .insert(devices)
    .values([
      {
        name: "Cyberpunk Battlestation",
        ipAddress: "192.168.1.120",
        isVirtual: true,
        ledCount: 120,
        voltage: 5,
        maxCurrentMa: 3000,
        power: true,
        brightness: 200,
        stateJson: JSON.stringify(deskState),
      },
      {
        name: "Living Room TV Bias Light",
        ipAddress: "192.168.1.145",
        isVirtual: true,
        ledCount: 60,
        voltage: 5,
        maxCurrentMa: 2000,
        power: true,
        brightness: 160,
        stateJson: JSON.stringify(tvState),
      },
      {
        name: "16x16 Pixel Art Matrix",
        ipAddress: "192.168.1.188",
        isVirtual: true,
        ledCount: 256,
        matrixWidth: 16,
        matrixHeight: 16,
        voltage: 5,
        maxCurrentMa: 4000,
        power: true,
        brightness: 175,
        stateJson: JSON.stringify(matrixState),
      },
      {
        name: "Kitchen Warm Cabinet Glow",
        ipAddress: "192.168.1.205",
        isVirtual: true,
        ledCount: 80,
        voltage: 5,
        maxCurrentMa: 2500,
        power: true,
        brightness: 220,
        stateJson: JSON.stringify(kitchenState),
      },
    ])
    .returning();

  // Create initial presets
  await db.insert(presets).values([
    {
      deviceId: inserted[0].id,
      name: "Synthwave Cyber Sunset",
      quickLoadKey: 1,
      stateData: JSON.stringify(deskState),
    },
    {
      deviceId: inserted[1].id,
      name: "Cozy Hearth Fire",
      quickLoadKey: 2,
      stateData: JSON.stringify(tvState),
    },
    {
      deviceId: inserted[2].id,
      name: "Matrix Cyber Rain",
      quickLoadKey: 3,
      stateData: JSON.stringify(matrixState),
    },
    {
      deviceId: inserted[3].id,
      name: "Nordic Warm Evening",
      quickLoadKey: 4,
      stateData: JSON.stringify(kitchenState),
    },
    {
      deviceId: inserted[0].id,
      name: "Police Emergency Strobe",
      quickLoadKey: 5,
      stateData: JSON.stringify({
        ...deskState,
        seg: [
          {
            ...deskState.seg[0],
            fx: 10, // Police
            sx: 220,
            ix: 255,
            col: [[255, 0, 0, 0], [0, 50, 255, 0], [255, 255, 255, 0]],
          },
        ],
      }),
    },
    {
      deviceId: inserted[0].id,
      name: "Northern Aurora Wave",
      quickLoadKey: 6,
      stateData: JSON.stringify({
        ...deskState,
        seg: [
          {
            ...deskState.seg[0],
            fx: 13, // Aurora
            sx: 60,
            ix: 150,
            pal: 8, // Aurora Borealis
            col: [[0, 255, 180, 0], [0, 100, 255, 0], [180, 0, 255, 0]],
          },
        ],
      }),
    },
  ]);

  return inserted;
}
