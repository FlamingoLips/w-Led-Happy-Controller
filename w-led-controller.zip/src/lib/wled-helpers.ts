import { WledDeviceState, WledSegmentState, WLED_PALETTES } from "./wled-constants";

export function rgbToHex(r: number, g: number, b: number): string {
  const toH = (c: number) => {
    const hex = Math.max(0, Math.min(255, Math.round(c))).toString(16);
    return hex.length === 1 ? "0" + hex : hex;
  };
  return `#${toH(r)}${toH(g)}${toH(b)}`.toUpperCase();
}

export function hexToRgb(hex: string): [number, number, number] {
  let clean = hex.replace("#", "").trim();
  if (clean.length === 3) {
    clean = clean.split("").map((c) => c + c).join("");
  }
  const num = parseInt(clean, 16);
  if (isNaN(num)) return [255, 255, 255];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

export function createDefaultState(ledCount: number = 60): WledDeviceState {
  return {
    on: true,
    bri: 180,
    transition: 7,
    ps: -1,
    pl: -1,
    nl: {
      on: false,
      dur: 15,
      mode: 1,
      tbri: 0,
      rem: 0,
    },
    udpn: {
      send: false,
      recv: false,
    },
    lor: 0,
    mainseg: 0,
    seg: [
      {
        id: 0,
        start: 0,
        stop: ledCount,
        len: ledCount,
        grp: 1,
        spc: 0,
        of: 0,
        on: true,
        bri: 255,
        col: [
          [255, 0, 120, 0],   // Primary Col 0: Neon Pink
          [0, 240, 255, 0],   // Secondary Col 1: Cyan
          [255, 180, 0, 0],   // Tertiary Col 2: Gold
        ],
        fx: 6, // Rainbow
        sx: 128,
        ix: 160,
        pal: 9, // Cyberpunk
        sel: true,
        rev: false,
        mi: false,
        name: "Main Zone",
      },
    ],
  };
}

export function estimatePowerConsumption(
  state: WledDeviceState,
  ledCount: number,
  voltage: number = 5,
  maxCurrentLimitMa: number = 2000
) {
  if (!state.on) {
    const idleCurrent = ledCount * 1.1; // ~1.1mA quiescent current per WS2812B controller chip
    return {
      currentMa: Math.round(idleCurrent),
      watts: Number(((idleCurrent / 1000) * voltage).toFixed(2)),
      percentOfLimit: Math.round((idleCurrent / maxCurrentLimitMa) * 100),
      isThrottled: false,
    };
  }

  const masterBriRatio = state.bri / 255;
  let totalEstimatedMa = 0;

  // Calculate per active segment
  state.seg.forEach((seg) => {
    if (!seg.on) return;
    const segLeds = Math.max(0, seg.stop - seg.start);
    const segBriRatio = (seg.bri ?? 255) / 255;
    const effRatio = masterBriRatio * segBriRatio;

    // Approximate color intensity: sum RGB / 3
    const primary = seg.col?.[0] || [255, 255, 255];
    const colorPowerFactor = ((primary[0] + primary[1] + primary[2]) / (255 * 3)) * 0.85 + 0.15;

    // A single WS2812B at 100% white is ~50mA.
    const perLedMa = 1.1 + 48.9 * effRatio * colorPowerFactor;
    totalEstimatedMa += segLeds * perLedMa;
  });

  const isThrottled = totalEstimatedMa > maxCurrentLimitMa;
  const currentMa = Math.min(totalEstimatedMa, maxCurrentLimitMa);
  const watts = Number(((currentMa / 1000) * voltage).toFixed(2));
  const percentOfLimit = Math.min(100, Math.round((currentMa / maxCurrentLimitMa) * 100));

  return {
    currentMa: Math.round(currentMa),
    watts,
    percentOfLimit,
    isThrottled,
  };
}

// Generate color for a specific LED index in an animated frame
export function sampleEffectColor(
  ledIndex: number,
  totalLeds: number,
  seg: WledSegmentState,
  timeMs: number,
  masterBri: number
): [number, number, number] {
  if (!seg.on || masterBri === 0) {
    return [0, 0, 0];
  }

  const segLen = Math.max(1, seg.stop - seg.start);
  let pos = (ledIndex - seg.start) / segLen;
  if (seg.rev) pos = 1 - pos;
  if (seg.mi && pos > 0.5) pos = 1 - pos;

  const speed = (seg.sx ?? 128) / 128;
  const intensity = (seg.ix ?? 128) / 255;
  const t = (timeMs / 1000) * speed;

  const c0 = seg.col?.[0] || [255, 0, 100];
  const c1 = seg.col?.[1] || [0, 200, 255];
  const c2 = seg.col?.[2] || [255, 180, 0];

  const palette = WLED_PALETTES.find((p) => p.id === seg.pal) || WLED_PALETTES[0];
  const paletteRgbList = palette.colors.map(hexToRgb);

  let r = c0[0];
  let g = c0[1];
  let b = c0[2];

  switch (seg.fx) {
    case 0: // Solid
      r = c0[0];
      g = c0[1];
      b = c0[2];
      break;

    case 1: { // Blink
      const blinkOn = Math.floor(t * 3) % 2 === 0;
      if (!blinkOn) return [0, 0, 0];
      r = c0[0];
      g = c0[1];
      b = c0[2];
      break;
    }

    case 2: { // Breathe
      const wave = (Math.sin(t * 2) + 1) / 2;
      const breathBri = 0.1 + 0.9 * wave;
      r = c0[0] * breathBri;
      g = c0[1] * breathBri;
      b = c0[2] * breathBri;
      break;
    }

    case 3: { // Wipe
      const sweep = (t * 2) % 2;
      const active = sweep < 1 ? pos < sweep : pos > sweep - 1;
      const col = active ? c0 : c1;
      r = col[0];
      g = col[1];
      b = col[2];
      break;
    }

    case 4: { // Dual Wipe
      const dualSweep = (t * 2) % 1;
      const distFromCenter = Math.abs(pos - 0.5) * 2;
      const active = distFromCenter < dualSweep;
      const col = active ? c0 : c1;
      r = col[0];
      g = col[1];
      b = col[2];
      break;
    }

    case 5: // Colorloop
    case 6: { // Rainbow
      const hue = ((pos + t * 0.3) % 1) * 360;
      const rgb = hsvToRgb(hue, 0.9, 1);
      r = rgb[0];
      g = rgb[1];
      b = rgb[2];
      break;
    }

    case 7: { // Rainbow Runner
      const offset = (pos * 4 - t * 2) % 1;
      const wave = Math.max(0, Math.sin(offset * Math.PI));
      const hue = ((pos + t * 0.5) % 1) * 360;
      const rgb = hsvToRgb(hue, 1, wave);
      r = rgb[0];
      g = rgb[1];
      b = rgb[2];
      break;
    }

    case 8: { // Fire 2012
      const flicker = Math.sin(pos * 18 + t * 8) * Math.cos(pos * 7 - t * 12);
      const heat = Math.max(0, Math.min(1, 0.5 + 0.5 * flicker + (1 - pos) * 0.3 * intensity));
      r = Math.min(255, Math.floor(heat * 300));
      g = Math.min(255, Math.floor(Math.max(0, heat - 0.3) * 320));
      b = Math.min(255, Math.floor(Math.max(0, heat - 0.7) * 400));
      break;
    }

    case 9: { // Candle
      const candleFlicker = 0.6 + 0.4 * (Math.sin(t * 14 + ledIndex * 3) * 0.5 + Math.cos(t * 7) * 0.5);
      r = Math.min(255, Math.floor(255 * candleFlicker));
      g = Math.min(255, Math.floor(140 * candleFlicker));
      b = Math.min(255, Math.floor(30 * candleFlicker));
      break;
    }

    case 10: { // Police / Scanner
      const half = pos < 0.5;
      const flash = Math.floor(t * 6) % 2 === 0;
      if (half && flash) {
        r = 255; g = 0; b = 10;
      } else if (!half && !flash) {
        r = 10; g = 50; b = 255;
      } else {
        r = 5; g = 5; b = 15;
      }
      break;
    }

    case 11: { // Twinkle
      const seed = Math.sin(ledIndex * 99 + Math.floor(t * 3));
      const sparkle = (Math.sin(seed * 10 + t * 5) + 1) / 2;
      if (sparkle > 0.75) {
        r = 255; g = 255; b = 255;
      } else {
        r = c0[0] * sparkle;
        g = c0[1] * sparkle;
        b = c0[2] * sparkle;
      }
      break;
    }

    case 13: { // Aurora
      const wave = (Math.sin(pos * 5 + t * 1.5) + Math.cos(pos * 2 - t * 0.8) + 2) / 4;
      const palIdx = Math.floor(wave * (paletteRgbList.length - 1));
      const col = paletteRgbList[palIdx] || [0, 255, 180];
      r = col[0];
      g = col[1];
      b = col[2];
      break;
    }

    case 14: { // Matrix Rain
      const fall = (pos * 8 - t * 4) % 1;
      const head = fall > 0.85 ? 1 : 0;
      const tail = Math.max(0, fall);
      r = head ? 220 : Math.floor(c0[0] * 0.1 * tail);
      g = head ? 255 : Math.floor(c0[1] * tail);
      b = head ? 220 : Math.floor(c0[2] * 0.2 * tail);
      break;
    }

    case 15: { // Chase
      const chasePos = (pos * 10 - t * 3) % 1;
      const glow = Math.pow(Math.max(0, 1 - Math.abs(chasePos - 0.5) * 2), 2);
      r = c0[0] * glow + c1[0] * (1 - glow) * 0.2;
      g = c0[1] * glow + c1[1] * (1 - glow) * 0.2;
      b = c0[2] * glow + c1[2] * (1 - glow) * 0.2;
      break;
    }

    default: {
      // Palette progression default
      const progress = (pos + t * 0.2) % 1;
      const indexFloat = progress * (paletteRgbList.length - 1);
      const idx1 = Math.floor(indexFloat);
      const idx2 = (idx1 + 1) % paletteRgbList.length;
      const frac = indexFloat - idx1;
      const p1 = paletteRgbList[idx1] || c0;
      const p2 = paletteRgbList[idx2] || c1;
      r = p1[0] * (1 - frac) + p2[0] * frac;
      g = p1[1] * (1 - frac) + p2[1] * frac;
      b = p1[2] * (1 - frac) + p2[2] * frac;
      break;
    }
  }

  // Factor in segment brightness and master brightness
  const segBri = (seg.bri ?? 255) / 255;
  const totalBri = (masterBri / 255) * segBri;

  return [
    Math.min(255, Math.max(0, Math.round(r * totalBri))),
    Math.min(255, Math.max(0, Math.round(g * totalBri))),
    Math.min(255, Math.max(0, Math.round(b * totalBri))),
  ];
}

function hsvToRgb(h: number, s: number, v: number): [number, number, number] {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r = 0, g = 0, b = 0;
  if (h >= 0 && h < 60) {
    r = c; g = x; b = 0;
  } else if (h >= 60 && h < 120) {
    r = x; g = c; b = 0;
  } else if (h >= 120 && h < 180) {
    r = 0; g = c; b = x;
  } else if (h >= 180 && h < 240) {
    r = 0; g = x; b = c;
  } else if (h >= 240 && h < 300) {
    r = x; g = 0; b = c;
  } else {
    r = c; g = 0; b = x;
  }
  return [
    Math.round((r + m) * 255),
    Math.round((g + m) * 255),
    Math.round((b + m) * 255),
  ];
}
